import java.util.Scanner;
import controller.EmployeeController;
import entity.Intern;
import service.EmployeeManager;


public class EmployeeMain {
	//create menu
	public static void showMenu() {
		System.out.println("Application Employee Manager");		
		System.out.println("-------------Menu-------------");
		System.out.println("1: To add Employee");
		System.out.println("2: To edit Employee");
		System.out.println("3: To delete Employee");
		System.out.println("4: To search Employee by id");
		System.out.println("5: To show Employees'information");
		System.out.println("6: To Exit");
		System.out.println("--------------------------------");
		System.out.println("Please choose:");
	}
	
	//create Classify
	public static void showEmployeeClassify() {
		System.out.println("------Employee Classify------");
		System.out.println("0: to add Employee's Experience");
		System.out.println("1: to add Employee's Fresher");
        System.out.println("2: to add Employee's Intern");
		System.out.println("--------------------------------");
		System.out.println("Please choose:");
	}
	
	//main
	public static void main(String[] args) {
//		Intern intern = new Intern();
//		intern.setUniversityName("Abc");
//		System.out.println(intern.toString());
		
		// Create 
		EmployeeController employeeController = new EmployeeController();
		EmployeeManager employeeManager = new EmployeeManager();
		//Scanner scanner = ScannerFactory.getScanner();
		Scanner scanner = new Scanner(System.in);
        while (true) {
        	//create menu
			showMenu();
            Integer inputNumber = scanner.nextInt();
            switch (inputNumber) {
                case 1: {
                	// input 0 => insert Experience
                    // input 1 => insert Fresher
                    // input 2 => insert Intern
                	showEmployeeClassify();
                    int type = scanner.nextInt();
                    switch (type) {
	                    case 0: {
	                    	employeeController.add(type);
	                        break;
	                    }
	                    case 1: {
	                    	employeeController.add(type);
	                        break;
	                    }
	                    case 2: {
	                    	employeeController.add(type);
	                        break;
	                    }
	                    default:
	                    	System.out.println("Invalid1");
	        				break;
                        }
                    	break;
                }
                case 2: {
                	//employeeController.update();
                	employeeController.EditInfor();
					break;					
				}
                case 3: {
                	Scanner scanner1 = new Scanner(System.in);
                	System.out.print("Enter id to remove: ");
                	String id = scanner1.nextLine();
                	System.out.println("id = "+id);
//                	employeeController.deleteById(id);
                	System.out.println(employeeController.deleteById(id) ? "Success" : "Fail");
                	//employeeManager.deleteEmployee(id);
                	//System.out.println(employeeManager.deleteEmployee(id) ? "Success" : "Fail");
					break;					
				}
                case 4: {
            		System.out.println("------Employee Classify------");
            		System.out.println("0: to Search Employee's Experience");
            		System.out.println("1: to Search Employee's Fresher");
                    System.out.println("2: to Search Employee's Intern");
            		System.out.println("--------------------------------");
            		System.out.println("Please choose:");
            		int type = scanner.nextInt();
            		switch (type) {
                    case 0: {
                    	employeeController.SearchbyExperience();
                        break;
                    }
                    case 1: {
                    	employeeController.SearchbyFresher();
                        break;
                    }
                    case 2: {
                    	employeeController.SearchbyIntern();
                        break;
                    }
                    default:
                    	System.out.println("Invalid1");
        				break;
                    }
                	break;					
				}
                case 5: {
                	employeeController.showAllEmployee();
					break;					
				}
                case 6: {
					return;
                }
                default:
                	System.out.println("Invalid2");
    				continue;
                 }
        }
	}

}
