package controller;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.regex.Pattern;
import entity.Certificate;
import entity.Employee;
import entity.Experience;
import entity.Fresher;
import entity.Intern;
import service.EmployeeManager;
import ui.ScannerFactory1;

public class EmployeeController {
	// Create object
	private EmployeeManager employeeManager = new EmployeeManager();

	/**
	 * @param type
	 * @return Employee type = 0 => Experience type = 1 => Fresher type = 2 =>
	 *         Intern
	 */
	// Add
	public void add(int type) {
		Employee employee = null;
		if (type == 0) {
			employee = createEmpExperienceInfor();
		}
		if (type == 1) {
			employee = createEmpFresherInfor();
		}
		if (type == 2) {
			employee = createEmpInternInfor();
		}
		// this.employeeManager.add(employee);
	}

	// Show
	public void showAllEmployee() {
		this.employeeManager.findAll().forEach(Employee::showInformation);
	}

	// Search by Experience
	public void SearchbyExperience() {
		this.employeeManager.SearchbyExperience();
	}

	// Search by Fresher
	public void SearchbyFresher() {
		this.employeeManager.SearchbyFresher();
	}

	// Search by Intern
	public void SearchbyIntern() {
		this.employeeManager.SearchbyIntern();
	}

	// Delete by id
	public boolean deleteById(String id) {
		return this.employeeManager.deleteEmployee(id);
	}

	// Edit employee information
	public void EditInfor() {
		System.out.print("Input ID to update: ");
		String id = ScannerFactory1.getScanner().nextLine();
		Employee employee = this.employeeManager.findById(id);
		if (employee == null) {
			System.out.println("không có data, bạn check lai nhe");
		} else {
			LocalDate birthDay = null;
			//String email;
			//employee = employee;
			// name
			System.out.print("Enter FullName:");
			String name = scanner.nextLine();
			employee.setFullName(name);
			// BirthDay
			System.out.print("Enter BirthDay:");
			// String birthDay = scanner.nextLine();
			String birthDay1 = "23/11/1999";
			checkdata(birthDay1);
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
			birthDay = LocalDate.parse(birthDay1, formatter);
			employee.setBirthday(birthDay);
			System.out.println(employee.toString());
		}
	}

	// Validdate date
	public static boolean isValidDate(String dateString) {
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		sdf.setLenient(false);
		try {
			sdf.parse(dateString.trim());
		} catch (ParseException e) {
			return false;
		}
		return true;
	}

	// Validdate date
	public String checkdata(String textString) {

		if (isValidDate(textString)) {
			// System.out.println("Birthday is Valid " );
			return textString;
		} else {
			System.out.println(textString);
			return null;
		}
	}

	// Validdate email
	public static boolean patternMatches(String emailAddress, String regexPattern) {
		return Pattern.compile(regexPattern).matcher(emailAddress).matches();
	}

	public static boolean isValidName(String name) {
		String regex = "^[A-Za-z\\s]{1,}[\\.]{0,1}[A-Za-z\\s]{0,}$";
		return name.matches(regex);
	}

	Scanner scanner = ScannerFactory1.getScanner();

	public Experience createEmpExperienceInfor() {

		LocalDate birthDay = null;
		String email;
		Experience experience = new Experience();
		try {
			// ID
			System.out.print("Enter ID: ");
			String id = scanner.nextLine();
			// scanner.nextLine();
			// FullName
			System.out.print("Enter FullName: ");
			String name = scanner.nextLine();
			// String name = "@tuan";
			if (isValidName(name)) {
				System.out.println("valid name");
			} else {
				System.out.println("invalid name");
				return null;
			}
			// BirthDay
			System.out.print("Enter BirthDay: ");
			String birthDay1 = scanner.nextLine();
			// String birthDay1 = "27/10/1990";
			checkdata(birthDay1);
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
			birthDay = LocalDate.parse(birthDay1, formatter);
			// Phone
			System.out.print("Enter Phone: ");
			String phone = scanner.nextLine();
			// Email
			System.out.print("Enter Email:");
			String email1 = scanner.nextLine();
			String regexPattern = "^[a-zA-Z0-9_!#$%&'*+/=?`{|}~^.-]+@[a-zA-Z0-9.-]+$";
			if (patternMatches(email1, regexPattern) == false) {
				System.out.println(" Invalid email");
				return null;
			} else {
				email = email1;
			}
			// certificates
			System.out.print("Input certificates: ");
			String certificates = scanner.nextLine();
			// Số năm kinh nghiệm (ExpInYear
			System.out.print("Input yearOfExperience: ");
			String yearOfExperience = scanner.nextLine();
			// kỹ năng chuyên môn (ProSkill)
			System.out.print("Input proSkill: ");
			String proSkill = scanner.nextLine();
			experience = new Experience(id, name, birthDay, phone, email, null, 0, proSkill);
			employeeManager.add(experience);
			System.out.println(experience.toString());
			// scanner.nextLine();
		} catch (Exception e) {
			System.out.println("invalid");
		}
		return experience;
		// return new Experience(id, name, null, Phone, email, null, 0, proSkill);
	}

	public Fresher createEmpFresherInfor() {
		String email;
		LocalDate birthDay = null;
		Fresher fresher = new Fresher();
		try {
			// ID
			System.out.print("Enter ID:");
			String id = scanner.nextLine();
			// scanner.nextLine();
			// FullName
			System.out.print("Enter FullName:");
			String name = scanner.nextLine();
			if (isValidName(name)) {
				System.out.println("valid name");
			} else {
				System.out.println("invalid name");
				return null;
			}
			// BirthDay
			System.out.print("Enter BirthDay:");
			String birthDay1 = scanner.nextLine();
			checkdata(birthDay1);
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
			birthDay = LocalDate.parse(birthDay1, formatter);
			// Phone
			System.out.print("Enter Phone:");
			String phone = scanner.nextLine();
			// Email
			System.out.print("Enter Email:");
			String email1 = scanner.nextLine();
			String regexPattern = "^[a-zA-Z0-9_!#$%&'*+/=?`{|}~^.-]+@[a-zA-Z0-9.-]+$";
			if (patternMatches(email1, regexPattern) == false) {
				System.out.println(" Invalid email");
				return null;
			} else {
				email = email1;
			}
			// certificates
			System.out.print("Input certificates: ");
			String certificates = scanner.nextLine();
			// graduationDate
			System.out.print("Input graduationDate: ");
			String graduationDate = scanner.nextLine();
			// graduationRank
			System.out.print("Input graduationRank: ");
			String graduationRank = scanner.nextLine();
			// universityName
			System.out.print("Input universityName: ");
			String universityName = scanner.nextLine();
			fresher = new Fresher(id, name, birthDay, phone, email, null, null, graduationRank, universityName);
			employeeManager.add(fresher);
			System.out.println(fresher.toString());
		} catch (Exception e) {
			System.out.println("invalid");
		}
		return fresher;
	}

	public Intern createEmpInternInfor() {
		String email;
		List<Certificate> cer = new ArrayList<Certificate>();
		LocalDate birthDay = null;
		Intern intern = new Intern();
		try {
			// ID
			System.out.print("Enter ID:");
			String id = scanner.nextLine();
			// FullName
			System.out.print("Enter FullName:");
			String name = scanner.nextLine();
			if (isValidName(name)) {
				System.out.println("valid name");
			} else {
				System.out.println("invalid name");
				return null;
			}
			// BirthDay
			System.out.print("Enter BirthDay:");
			String birthDay1 = scanner.nextLine();

			checkdata(birthDay1);
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
			birthDay = LocalDate.parse(birthDay1, formatter);
			// Phone
			System.out.print("Enter Phone:");
			String phone = scanner.nextLine();
			// Email
			System.out.print("Enter Email:");
			String email1 = scanner.nextLine();
			String regexPattern = "^[a-zA-Z0-9_!#$%&'*+/=?`{|}~^.-]+@[a-zA-Z0-9.-]+$";
			if (patternMatches(email1, regexPattern) == false) {
				System.out.println(" Invalid email");
				return null;
			} else {
				email = email1;
			}
			// certificates
			System.out.print("Input certificates: ");
			String certificates = scanner.nextLine();
			System.out.print("Input major: ");
			String major = scanner.nextLine();
			// semester
			System.out.print("Input semester: ");
			int semester = scanner.nextInt();
			scanner.nextLine();
			// universityName
			System.out.print("Input universityName1: ");
			String universityName = scanner.nextLine();
			System.out.println("universityName: " + universityName);
			scanner.nextLine();
			intern = new Intern(id, name, birthDay, phone, email, null, major, semester, universityName);
			employeeManager.add(intern);
			System.out.println(intern.toString());
		} catch (Exception e) {
			System.out.println("invalid");
		}
		return intern;
	}
}
