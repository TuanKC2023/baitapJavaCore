package service;

import java.util.ArrayList;
import java.util.List;
import entity.Employee;
import entity.Experience;
import entity.Fresher;
import entity.Intern;

public class EmployeeManager {
	private List<Employee> employees;
	
	public EmployeeManager() {
		this.employees = new ArrayList<Employee>();
	}
	
	// Add Employee
	public void add(Employee employee) {
		this.employees.add(employee);
	}
	
	//Find all Employee
	public List<Employee> findAll(){
		return this.employees;
	}
	
	//Search by Experience
	public void SearchbyExperience() {
		this.employees.stream().filter(emp ->emp instanceof Experience).forEach(emp ->System.out.println(emp.toString()));		
	}
	//Search by Fresher
	public void SearchbyFresher() {
		this.employees.stream().filter(emp ->emp instanceof Fresher).forEach(emp ->System.out.println(emp.toString()));		
	}
	//Search by Intern
	public void SearchbyIntern() {
		this.employees.stream().filter(emp ->emp instanceof Intern).forEach(emp ->System.out.println(emp.toString()));		
	}
	
	//Delete by Id
	public boolean deleteEmployee(String id) {
		Employee emp = this.employees.stream()
				.filter(employee -> employee.getId().equals(id))
				.findFirst().orElse(null);
		if (emp == null) {
			return false;
		}
		this.employees.remove(emp);
		return true;
	}
	
	//Delete by Id
	public boolean UpdateEmployee(String id) {
		Employee emp = this.employees.stream()
				.filter(employee -> employee.getId().equals(id))
				.findFirst().orElse(null);
		if (emp == null) {
			return false;
		}
		//this.employees.remove(emp);
		this.employees.add(emp);
		return true;
	}
	
	//Search by id  // Edit
    public Employee findById(String id) {
        return this.employees.stream().filter(employee -> employee.getId().equals(id)).findFirst().orElse(null);
    }
}


