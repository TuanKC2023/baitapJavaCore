/*
Navicat MySQL Data Transfer

Source Server         : 127.0.0.1
Source Server Version : 80034
Source Host           : 127.0.0.1:3306
Source Database       : student_management

Target Server Type    : MYSQL
Target Server Version : 80034
File Encoding         : 65001

Date: 2023-11-07 04:09:24
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for goodstudent
-- ----------------------------
DROP TABLE IF EXISTS `goodstudent`;
CREATE TABLE `goodstudent` (
  `id` int NOT NULL,
  `fullName` varchar(30) DEFAULT NULL,
  `gpa` float DEFAULT NULL,
  `bestRewardName` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of goodstudent
-- ----------------------------
INSERT INTO `goodstudent` VALUES ('1', 'Hoang van Thai', '9.8', 'Truong Ngoai Ngu');
INSERT INTO `goodstudent` VALUES ('2', 'Nguyen le Binh', '7.5', 'Truong KHTN');
INSERT INTO `goodstudent` VALUES ('3', 'Le Hoa Thom Ngat', '9.7', 'Truong Ngoai Ngu');
INSERT INTO `goodstudent` VALUES ('4', 'Hoang van Minh', '9.5', 'Truong Ngoai Ngu');
INSERT INTO `goodstudent` VALUES ('5', 'Bo Cong van Anh', '9.5', 'Truong Ngoai Ngu');
INSERT INTO `goodstudent` VALUES ('6', 'Khong Co Dươc', '9.3', 'Truong Ngoai Ngu');

-- ----------------------------
-- Table structure for normalstudent
-- ----------------------------
DROP TABLE IF EXISTS `normalstudent`;
CREATE TABLE `normalstudent` (
  `id` int NOT NULL,
  `fullName` varchar(30) DEFAULT NULL,
  `englishScore` float DEFAULT NULL,
  `entryTestScore` float DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of normalstudent
-- ----------------------------
INSERT INTO `normalstudent` VALUES ('1', 'Hoang van Thai', '9.8', '9.8');
INSERT INTO `normalstudent` VALUES ('2', 'Nguyen le Binh', '9.8', '10');
INSERT INTO `normalstudent` VALUES ('3', 'Le Hoa Thom Ngat', '8.9', '9.6');
INSERT INTO `normalstudent` VALUES ('4', 'Khong Co Dươc', '9.9', '9.8');
INSERT INTO `normalstudent` VALUES ('5', 'Bo Cong van Anh', '9.8', '10');

-- ----------------------------
-- Table structure for student
-- ----------------------------
DROP TABLE IF EXISTS `student`;
CREATE TABLE `student` (
  `id` int NOT NULL,
  `fullName` varchar(30) DEFAULT NULL,
  `doB` date NOT NULL DEFAULT '1970-01-01',
  `gender` varchar(10) DEFAULT NULL,
  `phoneNumber` varchar(10) DEFAULT NULL,
  `universityName` varchar(30) DEFAULT NULL,
  `gradeLevel` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of student
-- ----------------------------
INSERT INTO `student` VALUES ('1', 'Hoang van Thai', '2002-03-12', 'MALE', '0914567890', 'Truong Ngoai Ngu', 'NORMAL');
INSERT INTO `student` VALUES ('2', 'Nguyen le Binh', '2005-09-10', 'FEMALE', '0984567890', 'Truong KHTN', 'GOOD');
INSERT INTO `student` VALUES ('3', 'Le Hoa Thom Ngat', '2005-09-12', 'FEMALE', '0314567891', 'truong KHTN', 'GOOD');
INSERT INTO `student` VALUES ('4', 'Hoang van Minh', '2002-03-12', 'MALE', '0914567890', 'Truong Ngoai Ngu', 'NORMAL');
INSERT INTO `student` VALUES ('5', 'Khong Co Dươc', '2007-06-10', 'FEMALE', '0354567890', 'Truong KHTN', 'NORMAL');
INSERT INTO `student` VALUES ('6', 'Bo Cong van Anh', '2007-06-10', 'MALE', '0384567890', 'Truong KHTN', 'GOOD');
INSERT INTO `student` VALUES ('7', 'Hoang van Thai', '2002-03-13', 'FEMALE', '0914567889', 'Truong Ngoai Ngu', 'GOOD');
