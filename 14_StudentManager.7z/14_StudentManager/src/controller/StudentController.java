package controller;

import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;

import entity.GoodStudent;
import entity.Student;
import exception.InvalidDoBException;
import exception.InvalidFullNameException;
import exception.InvalidPhoneNumberException;
import impl.StudentImpl;
import service.StudentService;

public class StudentController {
	
	private static final List GoodStudent = null;
	ArrayList<Student> goodStudentList =null;
	ArrayList<Student> normalStudentList =null;
	//ArrayList<Student> students =null;
	public StudentService StudentServices;
	StudentService goodStudentImpl =new StudentImpl();
	public List<Student> getAllListStudent(int type) throws SQLException, ClassNotFoundException{
		
		if (type == 1) {
			goodStudentList = goodStudentImpl.getAllListSudent(type);
			return goodStudentList;
		}else {
			normalStudentList = goodStudentImpl.getAllListSudent(type);
			return normalStudentList;
		}
	}

	Student str1=null;
	
	public void showNormalStudentInfor() throws InvalidFullNameException, InvalidDoBException, InvalidPhoneNumberException {
		
		if(normalStudentList == null) {
			System.out.println("List Student empty");
			return;
		}
		System.out.println("============================");
        System.out.println("Show all good Student List");
        for (Student strNormalStudent: normalStudentList) {        	
			//fullNama
        	if (strNormalStudent.getFullName().length() < 10 || strNormalStudent.getFullName().length() > 50) {
				throw new InvalidFullNameException("Invalid name length");
			}
        	//doB
			SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
			try {
		        dateFormat.parse(String.valueOf(strNormalStudent.getDoB()));
		    } catch (ParseException e){
		        throw new InvalidDoBException("Invalid date format for doB");
		    }
			//phone
			if (!strNormalStudent.getPhoneNumber().matches("^(090|098|091|031|035|038)\\d{7}$")){
	            throw new InvalidPhoneNumberException("Invalid phone number format.");
	        }
			str1 = strNormalStudent;
			System.out.println(str1); 
		}
	}
		
	SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");    
	public void showGoodStudentInfor() throws InvalidFullNameException, InvalidDoBException, InvalidPhoneNumberException {
		if(goodStudentList == null) {
			System.out.println("List Student empty");
			return;
		}
		System.out.println("============================");
        System.out.println("Show all good Student List");
        for (Student strgoodStudent: goodStudentList) {
        	//fullNama
			if (strgoodStudent.getFullName().length() < 10 || strgoodStudent.getFullName().length() > 50) {
				throw new InvalidFullNameException("Invalid name length");
			}			
			//doB
			SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
			try {
		        dateFormat.parse(String.valueOf(strgoodStudent.getDoB()));
		    } catch (ParseException e){
		        throw new InvalidDoBException("Invalid date format for doB");
		    }
			//phone
			if (!strgoodStudent.getPhoneNumber().matches("^(090|098|091|031|035|038)\\d{7}$")){
	            throw new InvalidPhoneNumberException("Invalid phone number format.");
	        }
			str1 = strgoodStudent;
			System.out.println(str1); 
        }
	}
	
	public void showStudentInfor() {
		goodStudentImpl.ShowInfor();
	}
	
	Scanner scanner = new Scanner(System.in);
	static int seNumber;
	public void sapxep() {
		
		goodStudentList.size();
		System.out.println("check is: "+goodStudentList.size());
		System.out.println("Enter the number of students to recruit (min 11/ max 17) : ");
        seNumber = scanner.nextInt();
        seNumber =3;
        //students = goodStudentList;
        //sortStudentsByGpa(students);
        //System.out.println("goodStudentList is: "+goodStudentList);
        if (goodStudentList.size() >= seNumber){
            goodStudentList.stream()
                    .sorted((goodStudent1, goodStudent2) -> {
                        //int gpaCompare = Double.compare(goodStudent2.getGpa(), goodStudent1.getGpa());
                    	System.out.println("goodStudent2 is: "+goodStudent2);
                    	int gpaCompare = 0;
                        return gpaCompare != 0 ? gpaCompare : goodStudent1.getFullName().compareTo(goodStudent2.getFullName());
                    })
                    .limit(seNumber)
                    .forEach(System.out::println);
        }
	}
	public static void sortStudentsByGpa(ArrayList<GoodStudent> students) {
		//students.addAll(GoodStudent);
	       Collections.sort(students, new Comparator<GoodStudent>() {
	           public int compare(GoodStudent s1, GoodStudent s2) {
	               return Double.compare(s2.getGpa(), s1.getGpa());
	           }


	       });
	   }
	
	
}
