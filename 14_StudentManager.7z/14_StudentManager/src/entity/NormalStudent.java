package entity;

import java.util.Date;

import enums.Gender;
import enums.GradeLevel;

public class NormalStudent extends Student {
	private Double englishScore;
    private Double entryTestScore;
    
    
	public NormalStudent() {
		super();
		// TODO Auto-generated constructor stub
	}
	public NormalStudent(String fullName, String phoneNumber) {
		super(fullName, phoneNumber);
		// TODO Auto-generated constructor stub
	}
	public NormalStudent(String fullName, Date doB, Gender gender, String phoneNumber, String universityName,
			GradeLevel gradeLevel, Double englishScore, Double entryTestScore) {
		super(fullName, doB, gender, phoneNumber, universityName, gradeLevel);
		this.englishScore = englishScore;
		this.entryTestScore = entryTestScore;
	}

	public Double getEnglishScore() {
		return englishScore;
	}
	public void setEnglishScore(Double englishScore) {
		this.englishScore = englishScore;
	}
	public Double getEntryTestScore() {
		return entryTestScore;
	}
	public void setEntryTestScore(Double entryTestScore) {
		this.entryTestScore = entryTestScore;
	}
    
	@Override
	public String toString() {
		return "NormalStudent{" +  
	                 "  fullName='" + fullName + '\'' + 
	                 ", doB=" + doB + 
	                 ", gender='" + gender + '\'' + 
				     ", phoneNumber='" + phoneNumber + '\'' + 
				     ", universityName=" + universityName + 
				     ", gradeLevel=" + gradeLevel + 
				     ", englishScore=" + englishScore + 
				     ", entryTestScore='" + entryTestScore + '\'' + 
				     '}';
	}
}
