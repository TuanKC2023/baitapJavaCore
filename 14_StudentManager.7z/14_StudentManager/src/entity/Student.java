package entity;

import java.util.Date;

import enums.Gender;
import enums.GradeLevel;
import exception.InvalidFullNameException;

public class Student {
	protected String fullName;
	protected Date doB;
	protected Gender gender;
	protected String phoneNumber;
	protected String universityName;
	protected GradeLevel gradeLevel;
    
	public Student() {
	}
	
	public Student(String fullName, String phoneNumber) {
		this.fullName = fullName;
		this.phoneNumber = phoneNumber;
	}

	public Student(String fullName, Date doB, Gender gender, String phoneNumber, String universityName,
			GradeLevel gradeLevel) {
		this.fullName = fullName;
		this.doB = doB;
		this.gender = gender;
		this.phoneNumber = phoneNumber;
		this.universityName = universityName;
		this.gradeLevel = gradeLevel;
	}

	public String getFullName() {
		return fullName;
	}
	public void setFullName(String fullName) {
//		if (fullName.length() < 10 || fullName.length() > 50){
//          throw new InvalidFullNameException("Invalid name length");
//      }
		this.fullName = fullName;
	}
//	public void setFullName(String fullName) throws InvalidFullNameException {
//        if (fullName.length() < 10 || fullName.length() > 50){
//            throw new InvalidFullNameException("Invalid name length");
//        }
//        this.fullName = fullName;
//    }
	
	public Date getDoB() {
		return doB;
	}
	public void setDoB(Date doB) {
		this.doB = doB;
	}
	public Gender getGender() {
		return gender;
	}
	public void setGender(Gender gender) {
		this.gender = gender;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public String getUniversityName() {
		return universityName;
	}
	public void setUniversityName(String universityName) {
		this.universityName = universityName;
	}
	public GradeLevel getGradeLevel() {
		return gradeLevel;
	}
	public void setGradeLevel(GradeLevel gradeLevel) {
		this.gradeLevel = gradeLevel;
	}

	@Override
	public String toString() {
		return "Student [fullName=" + fullName + ", doB=" + doB + ", gender=" + gender + ", phoneNumber=" + phoneNumber
				+ ", universityName=" + universityName + ", gradeLevel=" + gradeLevel + "]";
	}  
	
}
