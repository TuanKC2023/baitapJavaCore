package enums;

public enum GradeLevel {
    NORMAL, GOOD
}
