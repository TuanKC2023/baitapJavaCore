package exception;

public class InvalidDoBException extends Exception {
    public InvalidDoBException(String message){
        super(message);
    }
}
