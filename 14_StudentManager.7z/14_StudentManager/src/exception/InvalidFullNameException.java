package exception;

public class InvalidFullNameException extends Exception{
    public InvalidFullNameException(String message){
        super(message);
    }
}
