package impl;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import entity.GoodStudent;
import entity.NormalStudent;
import entity.Student;
import enums.Gender;
import enums.GradeLevel;
import service.StudentService;
import util.ConnectionUtils;

public class StudentImpl implements StudentService {

	//private static final List GoodStudent = null;
	public ArrayList<Student> students =  new ArrayList<>();
	//GoodStudent goodStudent;

	@Override
	public ArrayList<Student> getAllListSudent(int type) throws SQLException, ClassNotFoundException {

		String sql = null;
		if (type  == 1) {
			sql = ("Select s.fullName, s.doB, s.gender,s.phoneNumber, s.universityName, s.gradeLevel, gs.gpa, gs.bestRewardName\n"
					+ "From student s\n" + "LEFT JOIN goodstudent gs ON gs.fullName = s.fullName;");
		}else if (type == 2){
		    sql = ("Select s.fullName, s.doB, s.gender,s.phoneNumber, s.universityName, s.gradeLevel, ns.englishScore, ns.entryTestScore\n"+
	                  "From student s\n" +
	                  "LEFT JOIN NormalStudent ns ON ns.fullName = s.fullName;");
		}else {
			
		}
		Connection connection = ConnectionUtils.getMySQLConnection();
		// Create object Statement.
		Statement statement = connection.createStatement();
		// Create object ResultSet.
		ResultSet resultSet = statement.executeQuery(sql);

        // show data
        while (resultSet.next()) {
            String fullName = resultSet.getString(1);              //System.out.println("fullName: " + fullName);
            java.util.Date doB = resultSet.getDate(2); //System.out.println("doB: " + doB);
            Gender gender = Gender.valueOf(resultSet.getString(3)); //System.out.println("gender: " + gender);
            //String gender = resultSet.getString(3);
            String phoneNumber = resultSet.getString(4); //System.out.println("phoneNumber: " + phoneNumber);
            String universityName = resultSet.getString(5); //System.out.println("universityName: " + universityName);
            GradeLevel gradeLevel = GradeLevel.valueOf(resultSet.getString(6));
            
            if (type == 1) {
            	Double gpa = resultSet.getDouble(7); //System.out.println("gpa: " + gpa);
                String bestRewardName = resultSet.getString(8); //System.out.println("bestRewardName: " + bestRewardName);
                Student goodStudent = new GoodStudent(fullName, doB, gender, phoneNumber, universityName, gradeLevel, gpa, bestRewardName);
                System.out.println(goodStudent.toString());
                students.add(goodStudent);
            }
            else {
            	Double englishScore = resultSet.getDouble(7);
                Double entryTestScore = resultSet.getDouble(8);
                Student normalStudent = new NormalStudent(fullName, doB, gender, phoneNumber, universityName, gradeLevel, englishScore , entryTestScore);
                System.out.println(normalStudent.toString());
                students.add(normalStudent);
            }
        }
		return students;
	}
	//2: Check leng FullName
		public boolean isValidFullName(String str) {
			int minLength = 10;
			int maxLength = 50;
			try {
				if ((str.length() > minLength) && (str.length() < maxLength)) {
					//System.out.println("Chuỗi có độ dài hợp lệ.");
					return true;
				}
			} catch (Exception e) {
				return false;
			}
			return false;
		}

	@Override
	public void ShowInfor() {
		if (students==null || students.isEmpty()) {
			System.out.println("List Student empty");
			return;
		}
		System.out.println(students.toString());
		for (Student strStudent: students) {        	
			System.out.println(strStudent); 
        }
	}
	
//	public void sortStudent() {
//		Collections.sort(goodStudent, new Comparator<Student>() {
//
//			@Override
//			public int compare(Student arg0, Student arg1) {
//				// TODO Auto-generated method stub
//				return 0;
//			}
//			
//		};)
//	}
	

	
	
	
	
	//@Override
	public class SortStudentByGPA implements Comparator<GoodStudent> {
	    public int compare(GoodStudent student1, GoodStudent student2) {
	        if (student1.getGpa() > student2.getGpa()) {
	            return 1;
	        }
	        return -1;
	    }
	}


}


