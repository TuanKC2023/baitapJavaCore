package main;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Scanner;

import controller.StudentController;
import entity.GoodStudent;
import entity.Student;
import exception.InvalidDoBException;
import exception.InvalidFullNameException;
import exception.InvalidPhoneNumberException;
import impl.StudentImpl;
import util.ConnectionUtils;



public class main {
	public static void main(String[] args) throws SQLException, ClassNotFoundException, InvalidFullNameException, InvalidDoBException, InvalidPhoneNumberException {
		System.out.println("Hello no14?");
		Scanner sc = new Scanner(System.in);
		StudentController studentController = new StudentController();
		while(true) {
			showMenu();
			int selectNumber = sc.nextInt();
			switch (selectNumber) {
				case 1:{
					showStudentType();
					int type = sc.nextInt();
					sc.nextLine();
					 switch (type) {
					 	case 1:{
					 		studentController.getAllListStudent(1);
					 		//studentController.showGoodStudentInfor();
	                        break;
					 	}
					 	case 2:{
					 		studentController.getAllListStudent(2);
					 		//studentController.showNormalStudentInfor();
	                        break;
					 	}
					 	default:
		                	System.out.println("Invalid1");
		    				break;
		                 }
					 break;
			     }
				case 2:{
					//studentController.Showin();
					studentController.showStudentInfor();
					break;
				}
				case 3:{
					//studentController.sapxep();
					studentController.sapxep();
					break;
				}
				case 6: {
					return;
				}
				default:
                	System.out.println("Invalid2");
    				continue;
                }
		}
		
	}

	public static void sortStudentsByGpa(ArrayList<GoodStudent> students) {
	       Collections.sort(students, new Comparator<GoodStudent>() {
	           public int compare(GoodStudent s1, GoodStudent s2) {
	               return Double.compare(s2.getGpa(), s1.getGpa());
	           }


	       });
	   }
	
	// create menu
	public static void showMenu() {
		System.out.println("Application Student Manager");
		System.out.println("-------------Menu-------------");
		System.out.println("1: To get Student from table");
		System.out.println("2: To Show Student All");
		System.out.println("3: To Exit");
		System.out.println("--------------------------------");
		System.out.println("Please choose:");
	}

	// StudentType
	public static void showStudentType() {
		System.out.println("----------Student type--------");
		System.out.println("1: to get GoodStudent from table");
		System.out.println("2: to get NormalStudent from table");
		System.out.println("--------------------------------");
		System.out.println("Please choose:");
	}
}
