package service;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import entity.GoodStudent;
import entity.Student;

public interface StudentService {
	//Create object Students list 
	ArrayList<Student> getAllListSudent(int type) throws SQLException, ClassNotFoundException;
	public void ShowInfor();
	//public void SortStudentByGPA();
}
