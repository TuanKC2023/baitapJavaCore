package util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectionUtils {
	public static Connection getMySQLConnection() throws ClassNotFoundException, SQLException {
		String hostName = "localhost";
		String dbName = "student_management";
	    String userName = "root";
	    String password = "12345678";
		return getMySQLConnection(hostName, dbName, userName, password);		
	}
	private static Connection getMySQLConnection(String hostName, String dbName, String userName, String password) throws ClassNotFoundException, SQLException {
		// Khai báo class Driver cho DB MySQL
		Class.forName("com.mysql.jdbc.Driver");
		 // Cấu trúc URL Connection MySQL
		String connectionURL = "jdbc:mysql://" + hostName + ":3306/" + dbName;
		Connection conn = null;
		conn = DriverManager.getConnection(connectionURL, userName, password);
		return conn;
		
	}
}
