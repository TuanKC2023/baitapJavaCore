/*
Navicat MySQL Data Transfer

Source Server         : 127.0.0.1
Source Server Version : 80034
Source Host           : 127.0.0.1:3306
Source Database       : student_management

Target Server Type    : MYSQL
Target Server Version : 80034
File Encoding         : 65001

Date: 2023-11-03 10:10:32
*/
CREATE DATABASE student_management;
USE student_management;

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for student
-- ----------------------------
DROP TABLE IF EXISTS `student`;
CREATE TABLE `student` (
  `id` int NOT NULL,
  `fullName` varchar(30) DEFAULT NULL,
  `doB` date NOT NULL DEFAULT '1970-01-01',
  `gender` varchar(10) DEFAULT NULL,
  `phoneNumber` varchar(10) DEFAULT NULL,
  `universityName` varchar(30) DEFAULT NULL,
  `gradeLevel` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of student
-- ----------------------------
INSERT INTO Student(id, fullName, doB, gender, phoneNumber, universityName, gradeLevel) VALUES 
('1', 'Hoang van Thai', '2002-03-12', 'male', '1234567890', 'Truong Ngoai Ngu', '1');
INSERT INTO Student(id, fullName, doB, gender, phoneNumber, universityName, gradeLevel) VALUES 
('2', 'Nguyen le Binh', '2005-09-10', 'Female', '0984567890', 'Truong KHTN', '2');
INSERT INTO Student(id, fullName, doB, gender, phoneNumber, universityName, gradeLevel) VALUES 
('3', "Le Xuan Hoa", "2005-09-12", "FEMALE", "0984567891", "truong KHTN", "2");
INSERT INTO Student(id, fullName, doB, gender, phoneNumber, universityName, gradeLevel) VALUES 
('4', 'Hoang van Minh', '2002-03-12', 'male', '1234567890', 'Truong Ngoai Ngu', '1');
INSERT INTO `Student(id, fullName, doB, gender, phoneNumber, universityName, gradeLevel)` VALUES 
('5', 'Nguyen le Binh', '2007-06-10', 'Female', '0984567890', 'Truong KHTN', '5');

INSERT INTO `Student(id, fullName, doB, gender, phoneNumber, universityName, gradeLevel)` VALUES 
('5', 'Binh', '2007-06-10', 'Female', '0984567890', 'Truong KHTN', '5');

SELECT fullName, phoneNumber FROM GoodStudent ORDER BY fullName DESC, phoneNumber ASC;
SELECT fullName, phoneNumber FROM NormalStudent ORDER BY fullName DESC, phoneNumber ASC;


-- ----------------------------
-- Table structure for goodstudent
-- ----------------------------
DROP TABLE IF EXISTS `goodstudent`;
CREATE TABLE `goodstudent` (
  `id` int NOT NULL,
  `fullName` varchar(30) DEFAULT NULL,
  `gpa` float(10) DEFAULT NULL,
  `bestRewardName` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO goodstudent(id, fullName, gpa, bestRewardName) VALUES 
('1', 'Hoang van Thai', '9.8', 'Truong KHTN');
INSERT INTO goodstudent(id, fullName, gpa, bestRewardName) VALUES 
('2', 'Nguyen le Binh', '7.5', 'Truong Ngoai Ngu');


Select s.fullName, s.doB, s.gender,s.phoneNumber, s.universityName, s.gradeLevel, gs.gpa, gs.bestRewardName
From student s
LEFT JOIN goodstudent gs ON gs.fullName = s.fullName

SELECT fullName, phoneNumber FROM goodstudent
UNION ALL
SELECT fullName, phoneNumber FROM NormalStudent ORDER BY fullName DESC, phoneNumber ASC;

-- ----------------------------
-- Table structure for NormalStudent
-- ----------------------------
DROP TABLE IF EXISTS `NormalStudent`;
CREATE TABLE `NormalStudent` (
  `id` int NOT NULL,
  `fullName` varchar(30) DEFAULT NULL,
  `englishScore` float(3) DEFAULT NULL,
  `entryTestScore` float(3) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


INSERT INTO NormalStudent(id, fullName, englishScore, entryTestScore) VALUES 
('1', 'Hoang van Thai', '9.8', '9.8');

SELECT * FROM GoodStudent
SELECT * FROM NormalStudent

Select s.fullName, s.doB, s.gender,s.phoneNumber, s.universityName, s.gradeLevel, ns.englishScore, ns.entryTestScore
From student s
LEFT JOIN NormalStudent ns ON ns.fullName = s.fullName;

Select gs.fullName
From goodstudent gs
    JOIN NormalStudent ns ON ns.fullName = gs.fullName;
	
Select gs.fullName,s.phoneNumber
From goodstudent gs
    JOIN NormalStudent ns ON ns.fullName = gs.fullName
    LEFT JOIN student s ON s.fullName = gs.fullName;	
	
	

SELECT fullName, phoneNumber FROM goodstudent
UNION ALL
SELECT fullName, phoneNumber FROM normalstudent
ORDER BY fullName DESC, phoneNumber ASC;

