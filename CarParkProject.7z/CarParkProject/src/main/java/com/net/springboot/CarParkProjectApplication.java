package com.net.springboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CarParkProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(CarParkProjectApplication.class, args);
	}

}
