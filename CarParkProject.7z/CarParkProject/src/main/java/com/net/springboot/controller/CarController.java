package com.net.springboot.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.net.springboot.dto.CarParkingInfo;
import com.net.springboot.model.Car;
import com.net.springboot.model.ResponseObject;
import com.net.springboot.service.CarService;

@RestController
@RequestMapping("/api/v1/Cars")
public class CarController {

	@Autowired
	private CarService carService;

	@GetMapping("")
	List<Car> getCarAllList() {
		return carService.getAllListCar();
	}
	@GetMapping("/info")
	List<CarParkingInfo> getAllListCarParkingInfo() {
		return carService.getAllListCarParkingInfo();
	}

	// Get By Id
	@GetMapping("/{licensePlace}")
	ResponseEntity<ResponseObject> getCarById(@PathVariable String licensePlace) {
		try {
			return ResponseEntity.status(HttpStatus.OK)
					.body(new ResponseObject("OK", "Get Car successfully", carService.getCarById(licensePlace)));
		} catch (Exception e) {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(new ResponseObject("Failed", e.getMessage(), ""));
		}
	}

	// Add BookingOffice
	@PostMapping("/add")
	ResponseEntity<ResponseObject> addParkingLot(@Valid @RequestBody Car newCar) {
		try {
			return ResponseEntity.status(HttpStatus.OK)
					.body(new ResponseObject("ok", "Add ParkingLot successfully", carService.addCar(newCar)));
		}catch (Exception e) {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(new ResponseObject("Failed", e.getMessage(), ""));
		}
	}
	
	// Delete
	@DeleteMapping("/{licensePlace}")
	ResponseEntity<ResponseObject> deleteCar(@PathVariable String licensePlace) {
		try {
			carService.deleteByLicensePlaceCar(licensePlace);
			return ResponseEntity.status(HttpStatus.OK)
					.body(new ResponseObject("ok", "Delete Car successfully with licensePlace = " + licensePlace, ""));
		} catch (Exception e) {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(new ResponseObject("failed", e.getMessage(), ""));
		}
	}

	// Edit
	@PutMapping("/{licensePlace}")
	ResponseEntity<ResponseObject> editCar(@Valid @RequestBody Car newCar, @PathVariable String licensePlace) {
		try {
			return ResponseEntity.status(HttpStatus.OK).body(new ResponseObject("ok", "Edit Car successfully",
					carService.editCarByLicensePlace(newCar, licensePlace)));
		} catch (Exception e) {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(new ResponseObject("failed", e.getMessage(), ""));
		}
	}
	
	//search By OfficeName Info	
	 @GetMapping("/cartype/{carType}")
	   public List<CarParkingInfo> searchByCarTypeInfo(@PathVariable("carType") String carType) {
	       return carService.searchByCarTypeInfo(carType);
	   }
	 
		// pageable
		@GetMapping("/pageable")
		Page<Car> getAllListCar_Pageable(@RequestParam(defaultValue = "0") int pageNumber,
				@RequestParam(defaultValue = "5") int pageSize, @RequestParam(defaultValue = "licensePlace") String sortBy) {
			Page<Car> page = carService.getAllListCar_Pageable(pageNumber, pageSize, sortBy);

			return page;
		}
}
