package com.net.springboot.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.net.springboot.dto.EmployeeInfo;
import com.net.springboot.model.Employee;
import com.net.springboot.model.ResponseObject;
import com.net.springboot.service.EmployeeService;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping(path = "/api/v1/Employees")
public class EmployeeController {

	@Autowired
	private EmployeeService employeeService;

	// Get All
	@GetMapping("")
	List<Employee> getAllEmployee() {
		return employeeService.getAllEmployee();
	}
	//Projection
		@GetMapping("/info")
		List<EmployeeInfo> getAllListEmployeeInfo() {
			return employeeService.getAllListEmployeeInfo();
		}
	// Get By Id
	@GetMapping("/{id}")
	ResponseEntity<ResponseObject> getEmployeeById(@PathVariable Long id) {
		try {
			return ResponseEntity.status(HttpStatus.OK)
					.body(new ResponseObject("OK", "Get Employee successfully", employeeService.getEmployeeById(id)));
		} catch (ClassCastException e) {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(new ResponseObject("Failed", e.getMessage(), ""));
		}

		catch (Exception e) {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(new ResponseObject("Failed", e.getMessage(), ""));
		}
	}

	//search By OfficeName Info	
	 @GetMapping("fullNames/{fullName}")
	   public List<EmployeeInfo> searchByOfficeNameInfo(@PathVariable("fullName") String fullName) {
	       return employeeService.searchByEmployyeeFullNameInfo(fullName);
	   }
	// Add Employee
	@PostMapping("/add")
	ResponseEntity<ResponseObject> addEmployee(@Valid @RequestBody Employee newEmployee) {

		if (newEmployee.getFullName() == null || newEmployee.getFullName().isEmpty()) {
			return ResponseEntity.status(HttpStatus.NOT_IMPLEMENTED)
					.body(new ResponseObject("failed", "Full Name Employee is null", ""));

		} else if (newEmployee.getFullName().length() > 50) {
			return ResponseEntity.status(HttpStatus.NOT_IMPLEMENTED)
					.body(new ResponseObject("failed", "Full Name Employee is too length", ""));
		} else {
			return ResponseEntity.status(HttpStatus.OK).body(
					new ResponseObject("ok", "Add Employee successfully", employeeService.addEmployee(newEmployee)));
		}
	}

	// Edit Employee
	@PutMapping("/{id}")
	ResponseEntity<?> editEmployee(@Valid @RequestBody Employee newEmployee, @PathVariable Long id) {
		try {
			return ResponseEntity.status(HttpStatus.OK).body(new ResponseObject("ok", "Edit Employee successfully",
					employeeService.editEmployeeById(newEmployee, id)));
		} catch (Exception e) {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(new ResponseObject("failed", e.getMessage(), ""));
		}

	}

	// Delete
	@DeleteMapping("/{id}")
	ResponseEntity<ResponseObject> deleteEmployee(@PathVariable Long id) {
		try {
			employeeService.deleteByIdEmployee(id);
			return ResponseEntity.status(HttpStatus.OK)
					.body(new ResponseObject("ok", "Delete Employee successfully with id = " + id, ""));
		} catch (Exception e) {
			return ResponseEntity.status(HttpStatus.NOT_FOUND)
					.body(new ResponseObject("failed", "Cannot find Employee to delete", ""));
		}
	}
	// pageable
	@GetMapping("/pageable")
	Page<Employee> getAllListBookingOfficeTrip_Pageable(@RequestParam(defaultValue = "0") int pageNumber,
			@RequestParam(defaultValue = "5") int pageSize, @RequestParam(defaultValue = "id") String sortBy) {
		Page<Employee> page = employeeService.getAllListEmployee_Pageable(pageNumber, pageSize, sortBy);

		return page;
	}
}
