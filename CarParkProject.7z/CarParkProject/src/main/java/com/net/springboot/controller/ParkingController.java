package com.net.springboot.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.net.springboot.model.ParkingLot;
import com.net.springboot.model.ResponseObject;
import com.net.springboot.service.ParkingSevice;

@RestController
@RequestMapping("/api/v1/Parkings")
public class ParkingController {
	@Autowired
	private ParkingSevice parkingSevice;

	@GetMapping("")
	List<ParkingLot> getParkingAllList() {
		return parkingSevice.getAllListParking();
	}
	
	//search By ParkName
	@GetMapping("/park/{parkName}")
	List<ParkingLot> searchByOfficeName(@PathVariable("parkName") String parkName) {
		return parkingSevice.searchByParkNameInfo(parkName);
	}

	//Get By Id
	@GetMapping("/{id}")
	ResponseEntity<ResponseObject> getParkingById(@PathVariable Long id) {
		try {
			return ResponseEntity.status(HttpStatus.OK)
					.body(new ResponseObject("OK", "Get ParkingLot successfully", parkingSevice.getParkingById(id)));
		} catch (Exception e) {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(new ResponseObject("Failed", e.getMessage(), ""));
		}
	}

	//Add ParkingLot
	@PostMapping("/add")
	ResponseEntity<ResponseObject> addParkingLot(@Valid @RequestBody ParkingLot newParkingLot) {
		try {
			return ResponseEntity.status(HttpStatus.OK).body(
					new ResponseObject("ok", "Add ParkingLot successfully", parkingSevice.addParkingLot(newParkingLot)));
		}catch (Exception e) {
			return ResponseEntity.status(HttpStatus.NOT_IMPLEMENTED).body(new ResponseObject("Failed", e.getMessage(), ""));
		}		
	}
	
	//Delete
	@DeleteMapping("/{id}")
	ResponseEntity<ResponseObject> deleteParkingLot(@PathVariable Long id) {
		try {
			parkingSevice.deleteByIdParkingLot(id);
			return ResponseEntity.status(HttpStatus.OK)
					.body(new ResponseObject("ok", "Delete ParkingLot successfully with id = " + id, ""));
		} catch (Exception e) {
			return ResponseEntity.status(HttpStatus.NOT_FOUND)
					.body(new ResponseObject("failed", e.getMessage(), ""));
		}
	}
	
	// Edit
	@PutMapping("/{id}")
	ResponseEntity<ResponseObject> editParkingLot(@Valid @RequestBody ParkingLot newParkingLot, @PathVariable Long id) {
		try {
			return ResponseEntity.status(HttpStatus.OK).body(new ResponseObject("ok", "Edit ParkingLot successfully",
					parkingSevice.editParkingById(newParkingLot, id)));
		} catch (Exception e) {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(new ResponseObject("failed", e.getMessage(), ""));
		}
	}
	
	// pageable
	@GetMapping("/pageable")
	Page<ParkingLot> getAllListBookingOfficeTrip_Pageable(@RequestParam(defaultValue = "0") int pageNumber,
			@RequestParam(defaultValue = "5") int pageSize, @RequestParam(defaultValue = "id") String sortBy) {
		Page<ParkingLot> page = parkingSevice.getAllListParkingLot_Pageable(pageNumber, pageSize, sortBy);

		return page;
	}
}
