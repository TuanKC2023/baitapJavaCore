package com.net.springboot.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.net.springboot.dto.TicketTripCarInfo;
import com.net.springboot.model.ResponseObject;
import com.net.springboot.model.Ticket;
import com.net.springboot.service.TicketService;

@RestController
@RequestMapping("/api/v1/Tickets")
public class TicketController {
	@Autowired
	private TicketService ticketService;

	@GetMapping("")
	List<Ticket> getTicketAllList() {
		return ticketService.getAllListTicket();
	}

	// Projection
	@GetMapping("/info")
	List<TicketTripCarInfo> getAllListTicketTripCarInfo() {
		return ticketService.getAllListTicketTripCarInfo();
	}

	//Get By Id
	@GetMapping("/{id}")
	ResponseEntity<ResponseObject> getBookingById(@PathVariable Long id) {
		try {
			return ResponseEntity.status(HttpStatus.OK)
					.body(new ResponseObject("OK", "Get Ticket successfully", ticketService.getTicketById(id)));
		} catch (Exception e) {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(new ResponseObject("failed", e.getMessage(), ""));
		}
	}
	
	// search By customerName Info
	@GetMapping("/customerName/{customerName}")
	public List<TicketTripCarInfo> searchByCustomerNameInfo(@PathVariable("customerName") String customerName) {
		return ticketService.searchByCustomerNameInfo(customerName);
	}

	//Add BookingOffice
	@PostMapping("/add")
	ResponseEntity<ResponseObject> addBookingOffice(@Valid @RequestBody Ticket newTicket) {
		return ResponseEntity.status(HttpStatus.OK)
				.body(new ResponseObject("ok", "Add Ticket successfully", ticketService.addTicket(newTicket)));
	}

	//Delete
	@DeleteMapping("/{id}")
	ResponseEntity<ResponseObject> deleteTicket(@PathVariable Long id) {
		try {
			ticketService.deleteTicketById(id);
			return ResponseEntity.status(HttpStatus.OK)
					.body(new ResponseObject("ok", "Delete Ticket successfully with id = " + id, ""));
		} catch (Exception e) {
			return ResponseEntity.status(HttpStatus.NOT_FOUND)
					.body(new ResponseObject("failed", e.getMessage(), ""));
		}
	}
	
	// pageable
	@GetMapping("/pageable")
	Page<Ticket> getAllListBookingOfficeTrip_Pageable(@RequestParam(defaultValue = "0") int pageNumber,
			@RequestParam(defaultValue = "5") int pageSize, @RequestParam(defaultValue = "id") String sortBy) {
		Page<Ticket> page = ticketService.getAllListTicket_Pageable(pageNumber, pageSize, sortBy);

		return page;
	}
}
