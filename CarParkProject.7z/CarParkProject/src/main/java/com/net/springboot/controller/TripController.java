package com.net.springboot.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.net.springboot.model.ResponseObject;
import com.net.springboot.model.Trip;
import com.net.springboot.service.TripSevice;

@RestController
@RequestMapping("/api/v1/Trips")
public class TripController {

	@Autowired
	private TripSevice tripSevice;

	// Get All List Trip
	@GetMapping("")
	List<Trip> GetAllListTrip() {
		return tripSevice.getAllListTrip();
	}

	// Get By Id
	@GetMapping("/{id}")
	ResponseEntity<ResponseObject> getTripById(@PathVariable Long id) {
		try {
			return ResponseEntity.status(HttpStatus.OK)
					.body(new ResponseObject("OK", "Get Trip successfully", tripSevice.getTripById(id)));
		} catch (Exception e) {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(new ResponseObject("Failed", e.getMessage(), ""));
		}

	}
	
	//search By Trip	
		 @GetMapping("/driver/{driver}")
		   public List<Trip> searchByDriver(@PathVariable("driver") String driver) {
		       return tripSevice.searchByDriver(driver);
		   }

	// Add Trip
	@PostMapping("/add")
	ResponseEntity<ResponseObject> addTrip(@Valid @RequestBody Trip newTrip) {
		try {
			return ResponseEntity.status(HttpStatus.OK)
					.body(new ResponseObject("ok", "Add Trip successfully", tripSevice.addTrip(newTrip)));
		} catch (Exception ex) {
			return ResponseEntity.status(HttpStatus.NOT_IMPLEMENTED).body(
					new ResponseObject("failed", "Can not add this Trip "+ ex.getMessage(), ""));
		}
	}

	// Delete
	@DeleteMapping("/{id}")
	ResponseEntity<ResponseObject> deleteTrip(@PathVariable Long id) {
		try {
			tripSevice.deleteByIdTrip(id);
			return ResponseEntity.status(HttpStatus.OK)
					.body(new ResponseObject("ok", "Delete Trip successfully with id = " + id, ""));
		} catch (Exception e) {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(new ResponseObject("failed", e.getMessage(), ""));
		}
	}

	// Edit
	@PutMapping("/{id}")
	ResponseEntity<ResponseObject> editParkingLot(@Valid @RequestBody Trip newTrip, @PathVariable Long id) {
		try {
			return ResponseEntity.status(HttpStatus.OK)
					.body(new ResponseObject("ok", "Edit Trip successfully", tripSevice.editTripById(newTrip, id)));
		} catch (Exception e) {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(new ResponseObject("failed", e.getMessage(), ""));
		}
	}
	
	// pageable
	@GetMapping("/pageable")
	Page<Trip> getAllListBookingOfficeTrip_Pageable(@RequestParam(defaultValue = "0") int pageNumber,
			@RequestParam(defaultValue = "5") int pageSize, @RequestParam(defaultValue = "id") String sortBy) {
		Page<Trip> page = tripSevice.getAllListTrip_Pageable(pageNumber, pageSize, sortBy);

		return page;
	}
}
