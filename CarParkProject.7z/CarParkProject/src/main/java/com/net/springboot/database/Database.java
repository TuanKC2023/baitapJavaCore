package com.net.springboot.database;

import java.sql.Time;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.net.springboot.model.BookingOffice;
import com.net.springboot.model.Employee;
import com.net.springboot.model.Trip;
import com.net.springboot.repository.BookingRepository;
import com.net.springboot.repository.EmployeeRepository;
import com.net.springboot.repository.TripRepository;

@Configuration
public class Database {
	//Logger
	private static final Logger logger = LoggerFactory.getLogger(Database.class);
	
	@Bean
	CommandLineRunner initDatabase(EmployeeRepository employeeRepository) {
		return new CommandLineRunner() {
			// init 2 record 
			@Override
			public void run(String... args) throws Exception {
				  Employee employeeA = new Employee("tuankc1", "Ky thuat", "address1", LocalDate.of(2005, 02, 20), "tuankc@gmail.com", "Kieu Cao Tuan","09345678", "123456","1"); 
				  Employee employeeB = new Employee("binhtg1", "Chu tich", "address2", LocalDate.of(2001, 03, 20), "bingtg1@gmail.com", "Truong Gia Binh","08345678", "123456","1");
				  Employee employeeC = new Employee("hoatm", "Chu tich", "address2", LocalDate.of(2007, 02, 22), "hoatm@gmail.com", "Truong My Hoa","08345678", "123456","0");
//				  logger.info("insert data:" + employeeRepository.save(employeeA));
//				  logger.info("insert data:" + employeeRepository.save(employeeB));
//				  logger.info("insert data:" + employeeRepository.save(employeeC));		
			}
		};	
	}
	
	@Bean
	CommandLineRunner initDatabaseBooking(BookingRepository bookingRepository) {
		return new CommandLineRunner() {
			// init 2 record 
			@Override
			public void run(String... args) throws Exception {
				  BookingOffice bookingOfficeA = new BookingOffice("Nguyen Van Vinh","901292","Quay so 1",200L,LocalDate.of(2001, 03, 20),LocalDate.of(2001, 03, 20), null);
				  BookingOffice bookingOfficeB = new BookingOffice("Nguyen Thi Lan","901292","Quay so 2",100L,LocalDate.of(2003, 03, 20),LocalDate.of(2003, 03, 20), null);
				  BookingOffice bookingOfficeC = new BookingOffice("Hoai phương","901292","Quay so 3",300L,LocalDate.of(2003, 03, 20),LocalDate.of(2003, 03, 20), null);
//				  logger.info("insert data:" + bookingRepository.save(bookingOfficeA));
//				  logger.info("insert data:" + bookingRepository.save(bookingOfficeB));
//				  logger.info("insert data:" + bookingRepository.save(bookingOfficeC));

			}
		};	
	}
	
	@Bean
	CommandLineRunner initDatabaseTRip(TripRepository tripRepository) {
		return new CommandLineRunner() {
			// init 2 record 
			@Override
			public void run(String... args) throws Exception {
				Trip tripA = new Trip(0,"Giuong nam 50 Cho",LocalDate.of(2001, 03, 20),null, "Gia Lai", "Tran Van Loc", 50);
				Trip tripB = new Trip(1,"Giuong nam 70 Cho",LocalDate.of(2001, 03, 20),null, "Gia Lai", "Tran Van Loc", 70);
//				  logger.info("insert data:" + tripRepository.save(tripA));
//				  logger.info("insert data:" + tripRepository.save(tripB));
			}
		};	
	}
	
//	@Bean
//	CommandLineRunner initDatabaseTrip(TripRepository tripRepository) {
//		return new CommandLineRunner() {
//			// init 2 record 
//			@Override
//			public void run(String... args) throws Exception {
//				Trip tripA = new Trip(0, "Guong nam 50 cho", LocalDate.of(2005, 02, 20), LocalTime.parse("10:30:00"), "Gia lai","Tran van Luc", 1, null); 
//				Trip tripB = new Trip(1, "Guong nam 50 cho", LocalDate.of(2005, 02, 20), LocalTime.parse("11:10:00"), "Khanh Hoa","Tran Cong Phuc", 1, null); 
////				logger.info("insert data:" + tripRepository.save(tripA));
////				logger.info("insert data:" + tripRepository.save(tripB));
//				
//			}
//		};	
//	}
}
