package com.net.springboot.dto;

public interface BookingOfficeTripInfo {
	long getId();

	String getOfficeName();

	TripWithId getTrip();

	interface TripWithId {
		String getDestination();
	}
}
