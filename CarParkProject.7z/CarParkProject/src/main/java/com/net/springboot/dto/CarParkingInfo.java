package com.net.springboot.dto;

public interface CarParkingInfo {
	String getLicensePlace();
	
	String getCarColor();
	
	String getCarType();
	
	String getCompany();
	
	ParkingWithId getParkingLot();

	interface ParkingWithId {
		String getParkName();
	}
}
