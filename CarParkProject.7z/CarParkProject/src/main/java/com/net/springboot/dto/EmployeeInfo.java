package com.net.springboot.dto;

import java.time.LocalDate;

public interface EmployeeInfo {
	long getId();
	String getFullName();
	LocalDate getDateOfBirth();
	String getAddress();
	String getPhoneNumber();
	String getDepartment();
}
