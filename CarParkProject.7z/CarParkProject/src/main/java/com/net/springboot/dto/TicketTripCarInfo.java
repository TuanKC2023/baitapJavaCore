package com.net.springboot.dto;

import java.sql.Time;

public interface TicketTripCarInfo {
	TripWithId getTrip();

	interface TripWithId {
		String getDestination();
	}

	CarWithId getCar();

	interface CarWithId {
		String getLicensePlace();
	}

	long getId();

	String getCustomerName();

	Time getBookingTime();
}
