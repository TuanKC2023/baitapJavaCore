package com.net.springboot.exception;

import java.util.HashMap;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.net.springboot.model.ResponseObject;

@RestControllerAdvice
public class GlobalExceptionHandler {
	String errorMessage1=null;
	@ExceptionHandler(MethodArgumentNotValidException.class)
	public ResponseEntity<ResponseObject> handleValidationExceptions(MethodArgumentNotValidException ex){
		Map<String, String> errors = new HashMap<>();
	       ex.getBindingResult().getAllErrors().forEach((error) -> {
	           String fieldName = ((FieldError) error).getField();
	           System.out.println("fieldName: "+fieldName);
	           String errorMessage = error.getDefaultMessage();	           
	           errorMessage1 =errorMessage;
	           //System.out.println("errorMessage: "+errorMessage);
	           errors.put(fieldName, errorMessage);           
	       });
	       return ResponseEntity.status(HttpStatus.NOT_IMPLEMENTED).body(
					 new ResponseObject("Failed", errorMessage1, "")
					);	
	}
}
