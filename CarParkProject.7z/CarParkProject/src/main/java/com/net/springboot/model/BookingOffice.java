package com.net.springboot.model;

import java.time.LocalDate;

import javax.persistence.*;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonFormat;

@Entity
@Table(name = "tblBookingOffice")
public class BookingOffice {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "office_id", length = 20)
	private long id;
	
	@Column(name = "office_Name", length = 50, nullable = false)
	@NotBlank(message = "officeName cannot be null or empty")
	@Size(max = 50, message = "officeName cannot be more than 50 characters")
	private String officeName;
	
	@Column(name = "office_Phone", length = 11, nullable = false)
	@NotBlank(message = "officePhone cannot be null or empty")
	@Size(max = 11, message = "officePhone cannot be more than 11 characters")
	private String officePhone;
	
	@Column(name = "office_Place", length = 50, nullable = false)
	@NotBlank(message = "officePlace cannot be null or empty")
	@Size(max = 50, message = "officePlace cannot be more than 50 characters")
	private String officePlace;
	
	@Column(name = "office_Price", length = 20, nullable = false)
	//@NotNull(message = "officePrice cannot be null or empty")
	@NotNull
	//@Size(max = 20, message = "officePrice cannot be more than 20 characters")
	private long officePrice;
	
	@Column(name = "start_Contract_Deadline", nullable = false)
	@NotNull(message = "startContractDeadline cannot be null or empty")
	@JsonFormat(pattern="yyyy-MM-dd")
	private LocalDate startContractDeadline;
	
	@Column(name = "end_Contract_Deadline", nullable = false)
	@NotNull(message = "endContractDeadline cannot be null or empty")
	@JsonFormat(pattern="yyyy-MM-dd")
	private LocalDate endContractDeadline;
	
    @ManyToOne 
    @JoinColumn(name = "trip_id", referencedColumnName = "trip_id")
	private Trip trip;

	public BookingOffice() {}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getOfficeName() {
		return officeName;
	}

	public void setOfficeName(String officeName) {
		this.officeName = officeName;
	}

	public String getOfficePhone() {
		return officePhone;
	}

	public void setOfficePhone(String officePhone) {
		this.officePhone = officePhone;
	}

	public String getOfficePlace() {
		return officePlace;
	}

	public void setOfficePlace(String officePlace) {
		this.officePlace = officePlace;
	}

	public long getOfficePrice() {
		return officePrice;
	}

	public void setOfficePrice(long officePrice) {
		this.officePrice = officePrice;
	}

	public LocalDate getStartContractDeadline() {
		return startContractDeadline;
	}

	public void setStartContractDeadline(LocalDate startContractDeadline) {
		this.startContractDeadline = startContractDeadline;
	}

	public LocalDate getEndContractDeadline() {
		return endContractDeadline;
	}

	public void setEndContractDeadline(LocalDate endContractDeadline) {
		this.endContractDeadline = endContractDeadline;
	}

	public Trip getTrip() {
		return trip;
	}

	public void setTrip(Trip trip) {
		this.trip = trip;
	}

	public BookingOffice(String officeName, String officePhone, String officePlace, long officePrice,
			LocalDate startContractDeadline, LocalDate endContractDeadline, Trip trip) {
		this.officeName = officeName;
		this.officePhone = officePhone;
		this.officePlace = officePlace;
		this.officePrice = officePrice;
		this.startContractDeadline = startContractDeadline;
		this.endContractDeadline = endContractDeadline;
		this.trip = trip;
	}

	@Override
	public String toString() {
		return "BookingOffice [id=" + id + ", officeName=" + officeName + ", officePhone=" + officePhone
				+ ", officePlace=" + officePlace + ", officePrice=" + officePrice + ", startContractDeadline="
				+ startContractDeadline + ", endContractDeadline=" + endContractDeadline + ", trip=" + trip + "]";
	}
	
	
}
