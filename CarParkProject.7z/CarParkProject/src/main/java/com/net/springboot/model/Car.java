package com.net.springboot.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

//@SQLDelete(sql = "UPDATE Car SET deleted = true WHERE id = ?")
//@Where(clause = "deleted = false")
@Entity
@Table(name = "tblCar")
public class Car {
	@Id
	@Column(name = "license_Place", length = 20, nullable = false)
	@NotBlank(message = "licensePlace cannot be null or empty")
	@Size(max = 20, message = "licensePlace cannot be more than 20 characters")
	private String licensePlace;
	
	@Column(name = "car_Color", length = 20, nullable = false)
	@NotBlank(message = "carColor cannot be null or empty")
	@Size(max = 20, message = "carColor cannot be more than 20 characters")
	private String carColor;
	
	@Column(name = "car_Type", length = 50, nullable = false)
	@NotBlank(message = "carType cannot be null or empty")
	@Size(max = 50, message = "carType cannot be more than 50 characters")
	private String carType;
	
	@Column(name = "company", length = 50, nullable = false)
	@NotBlank(message = "company cannot be null or empty")
	@Size(max = 50, message = "company cannot be more than 50 characters")
	private String company;
	
	@ManyToOne 
	@JoinColumn(name = "park_id", referencedColumnName = "park_id")
	private ParkingLot parkingLot;
	
	//private Boolean deleted = Boolean.FALSE;;
	
//	@OneToMany(mappedBy = "car", cascade = CascadeType.ALL)
//	private List<Ticket> ticket;

	
	public Car() {
	}

	public String getLicensePlace() {
		return licensePlace;
	}

	public void setLicensePlace(String licensePlace) {
		this.licensePlace = licensePlace;
	}

	public String getCarColor() {
		return carColor;
	}

	public void setCarColor(String carColor) {
		this.carColor = carColor;
	}

	public String getCarType() {
		return carType;
	}

	public void setCarType(String carType) {
		this.carType = carType;
	}

	public String getCompany() {
		return company;
	}

	public void setCompany(String company) {
		this.company = company;
	}

	public ParkingLot getParkingLot() {
		return parkingLot;
	}

	public void setParkingLot(ParkingLot parkingLot) {
		this.parkingLot = parkingLot;
	}

	public Car(String licensePlace, String carColor, String carType, String company, ParkingLot parkingLot) {
		this.licensePlace = licensePlace;
		this.carColor = carColor;
		this.carType = carType;
		this.company = company;
		this.parkingLot = parkingLot;
	}

	@Override
	public String toString() {
		return "Car [licensePlace=" + licensePlace + ", carColor=" + carColor + ", carType=" + carType + ", company="
				+ company + ", parkingLot=" + parkingLot + "]";
	}
	

}
