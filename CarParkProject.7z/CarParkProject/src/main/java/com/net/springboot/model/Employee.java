package com.net.springboot.model;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonFormat;

@Entity
@Table(name = "tblEmployee")
public class Employee {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "employee_id", length = 20)
	private long id;

	@Column(name = "Acount", length = 50, nullable = false, unique = true)
	@NotBlank(message = "acount cannot be null or empty")
	@Size(max = 50, message = "acount cannot be more than 50 characters")
	private String acount;

	@Column(name = "Department", length = 10, nullable = false)
	@NotBlank(message = "department cannot be null or empty")
	@Size(max = 10, message = "department cannot be more than 10 characters")
	private String department;

	@Column(name = "Address", length = 50)
	private String address;

	@Column(name = "date_Of_Birth", nullable = false)
	@NotNull(message = "dateOfBirth cannot be null or empty")
	@JsonFormat(pattern = "yyyy-MM-dd")
	private LocalDate dateOfBirth;

	@Column(name = "Email", length = 50)
	private String email;

	@Column(name = "full_Name", length = 50, nullable = false)
	@NotBlank(message = "fullName cannot be null or empty")
	@Size(max = 50, message = "fullName cannot be more than 50 characters")
	private String fullName;

	@Column(name = "phone_Number", length = 10, nullable = false)
	@NotBlank(message = "phoneNumber cannot be null or empty")
	@Size(max = 10, message = "phoneNumber cannot be more than 10 characters")
	private String phoneNumber;

	@Column(name = "Password", length = 20, nullable = false)
	@NotBlank(message = "password cannot be null or empty")
	@Size(max = 20, message = "password cannot be more than 20 characters")
	private String password;

	@Column(name = "Sex", length = 1, nullable = false) // choose 0 or 1
	@NotBlank(message = "sex cannot be null or empty")
	@Size(max = 1, message = "sex cannot be more than 1 characters")
	private String sex;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getAcount() {
		return acount;
	}

	public void setAcount(String acount) {
		this.acount = acount;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public LocalDate getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(LocalDate dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getSex() {
		return sex;
	}

	public void setSex(String sex) {
		this.sex = sex;
	}

	public Employee() {
	}

	public Employee(String acount, String department, String address, LocalDate dateOfBirth, String email,
			String fullName, String phoneNumber, String password, String sex) {
		this.acount = acount;
		this.department = department;
		this.address = address;
		this.dateOfBirth = dateOfBirth;
		this.email = email;
		this.fullName = fullName;
		this.phoneNumber = phoneNumber;
		this.password = password;
		this.sex = sex;
	}

	@Override
	public String toString() {
		return "Employee [id=" + id + ", acount=" + acount + ", department=" + department + ", address=" + address
				+ ", dateOfBirth=" + dateOfBirth + ", email=" + email + ", fullName=" + fullName + ", phoneNumber="
				+ phoneNumber + ", password=" + password + ", sex=" + sex + "]";
	}

}
