package com.net.springboot.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Entity
@Table(name = "tblParking")
public class ParkingLot {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "park_id", length = 20)
	private long id;
	
	@Column(name = "park_Area", length = 20, nullable = false)
	@NotNull(message = "parkArea cannot be null or empty")
    private long parkArea;
	
	@Column(name = "park_Name", length = 50, nullable = false)
	@NotBlank(message = "parkName cannot be null or empty")
	@Size(max = 50, message = "parkName cannot be more than 50 characters")
    private String parkName;
	
	@Column(name = "park_Place", length = 11, nullable = false)
	@Size(max = 11, message = "parkPlace cannot be more than 11 characters")
	@NotBlank(message = "parkPlace cannot be null or empty")
    private String parkPlace;
	
	@Column(name = "park_Price", length = 20, nullable = false)
	@NotNull(message = "parkPrice cannot be null or empty")
    private long parkPrice;
	
	@Column(name = "park_Status", length = 50, nullable = false)
    private String parkStatus;
	
	//private Boolean deleted = Boolean.FALSE;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public long getParkArea() {
		return parkArea;
	}

	public void setParkArea(long parkArea) {
		this.parkArea = parkArea;
	}

	public String getParkName() {
		return parkName;
	}

	public void setParkName(String parkName) {
		this.parkName = parkName;
	}

	public String getParkPlace() {
		return parkPlace;
	}

	public void setParkPlace(String parkPlace) {
		this.parkPlace = parkPlace;
	}

	public long getParkPrice() {
		return parkPrice;
	}

	public void setParkPrice(long parkPrice) {
		this.parkPrice = parkPrice;
	}

	public String getParkStatus() {
		return parkStatus;
	}

	public void setParkStatus(String parkStatus) {
		this.parkStatus = parkStatus;
	}

	public ParkingLot() {
	}

	public ParkingLot(@NotNull(message = "parkArea cannot be null or empty") long parkArea,
			@NotBlank(message = "parkName cannot be null or empty") @Size(max = 50, message = "parkName cannot be more than 50 characters") String parkName,
			@Size(max = 11, message = "parkPlace cannot be more than 11 characters") @NotBlank(message = "parkPlace cannot be null or empty") String parkPlace,
			@NotNull(message = "parkPrice cannot be null or empty") long parkPrice, String parkStatus) {
		this.parkArea = parkArea;
		this.parkName = parkName;
		this.parkPlace = parkPlace;
		this.parkPrice = parkPrice;
		this.parkStatus = parkStatus;
	}
	
	

	

	

	

}
