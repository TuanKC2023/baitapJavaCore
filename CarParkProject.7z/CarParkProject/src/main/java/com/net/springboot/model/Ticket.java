package com.net.springboot.model;

import java.sql.Time;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Entity
@Table(name = "tblTicket")
public class Ticket {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ticket_id", length = 20, nullable = false)
	private long id;
	
	@Column(name = "booking_Time")
	@NotNull(message = "bookingTime cannot be null or empty")
	private Time bookingTime;
	
	@Column(name = "customer_Name", length = 50, nullable = false)
	@NotBlank(message = "customerName cannot be null or empty")
	@Size(max = 50, message = "customerName cannot be more than 50 characters")
	private String customerName;
	
	@ManyToOne
	@JoinColumn(name = "licensePlace", referencedColumnName = "license_Place", nullable = false) 
	//@NotBlank(message = "car cannot be null or empty")
	private Car car;
	
    @ManyToOne 
    @JoinColumn(name = "trip_id", referencedColumnName = "trip_id", nullable = false)
    //@NotBlank(message = "trip cannot be null or empty")
	private Trip trip;

	public Ticket() {}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public Time getBookingTime() {
		return bookingTime;
	}

	public void setBookingTime(Time bookingTime) {
		this.bookingTime = bookingTime;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public Car getCar() {
		return car;
	}

	public void setCar(Car car) {
		this.car = car;
	}

	public Trip getTrip() {
		return trip;
	}

	public void setTrip(Trip trip) {
		this.trip = trip;
	}

	public Ticket(Time bookingTime, String customerName, Car car, Trip trip) {
		super();
		this.bookingTime = bookingTime;
		this.customerName = customerName;
		this.car = car;
		this.trip = trip;
	}

	@Override
	public String toString() {
		return "Ticket [id=" + id + ", bookingTime=" + bookingTime + ", customerName=" + customerName + ", car=" + car
				+ ", trip=" + trip + "]";
	}
    
    
}
