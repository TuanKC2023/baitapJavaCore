package com.net.springboot.model;

import java.time.LocalDate;
import java.time.LocalTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name = "tblTrip")
public class Trip {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "trip_id", length = 20, nullable = false)
	private long id;
	
	@Column(name = "booked_Ticket_number", length = 11)
    private long bookedTicketnumber;
	
	@Column(name = "car_Type", length = 50, nullable = false)
	@NotBlank(message = "carType cannot be null or empty")
	@Size(max = 50, message = "carType cannot be more than 50 characters")
    private String carType;
	
	@Column(name = "departure_Date", nullable = false)
	@NotNull(message = "departureDate cannot be null or empty")
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private LocalDate departureDate;
    
	@Column(name = "departure_Time", nullable = false)
	@NotNull(message = "departureTime cannot be null or empty")
	@DateTimeFormat(pattern = "HH:mm:ss")
	private LocalTime departureTime;
	
	@Column(name = "destination", length = 50, nullable = false)
	@NotBlank(message = "destination cannot be null or empty")
	@Size(max = 50, message = "destination cannot be more than 50 characters")
    private String destination;
	
	@Column(name = "driver", length = 50, nullable = false)
	@NotBlank(message = "driver cannot be null or empty")
	@Size(max = 50, message = "driver cannot be more than 50 characters")
    private String driver;
	
	@Column(name = "maximum_Online_Ticket_number", length = 11, nullable = false)
	@NotNull(message = "maximumOnlineTicketnumber cannot be null or empty")
	//@Size(max = 11, message = "driver cannot be more than 11 characters")
    private long maximumOnlineTicketnumber;

//    @OneToMany(mappedBy = "trip", cascade = CascadeType.ALL)
//    @PrimaryKeyJoinColumn
//    private List<BookingOffice> bookingOffice;
//    
//    @OneToMany(mappedBy = "trip", cascade = CascadeType.ALL)
//    private List<Ticket> ticket;

	public Trip() {
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public long getBookedTicketnumber() {
		return bookedTicketnumber;
	}

	public void setBookedTicketnumber(long bookedTicketnumber) {
		this.bookedTicketnumber = bookedTicketnumber;
	}

	public String getCarType() {
		return carType;
	}

	public void setCarType(String carType) {
		this.carType = carType;
	}

	public LocalDate getDepartureDate() {
		return departureDate;
	}

	public void setDepartureDate(LocalDate departureDate) {
		this.departureDate = departureDate;
	}

	public LocalTime getDepartureTime() {
		return departureTime;
	}

	public void setDepartureTime(LocalTime departureTime) {
		this.departureTime = departureTime;
	}

	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	public String getDriver() {
		return driver;
	}

	public void setDriver(String driver) {
		this.driver = driver;
	}

	public long getMaximumOnlineTicketnumber() {
		return maximumOnlineTicketnumber;
	}

	public void setMaximumOnlineTicketnumber(long maximumOnlineTicketnumber) {
		this.maximumOnlineTicketnumber = maximumOnlineTicketnumber;
	}

//	public List<BookingOffice> getBookingOffice() {
//		return bookingOffice;
//	}
//
//	public void setBookingOffice(List<BookingOffice> bookingOffice) {
//		this.bookingOffice = bookingOffice;
//	}

	public Trip(long bookedTicketnumber, String carType, LocalDate departureDate, LocalTime departureTime,
			String destination, String driver, long maximumOnlineTicketnumber) {
		this.bookedTicketnumber = bookedTicketnumber;
		this.carType = carType;
		this.departureDate = departureDate;
		this.departureTime = departureTime;
		this.destination = destination;
		this.driver = driver;
		this.maximumOnlineTicketnumber = maximumOnlineTicketnumber;
//		this.bookingOffice = bookingOffice;
	}

	@Override
	public String toString() {
		return "Trip {"+
				"id=" + id + ", bookedTicketnumber=" + bookedTicketnumber + ", carType=" + carType
				+ ", departureDate=" + departureDate + ", departureTime=" + departureTime + ", destination="
				+ destination + ", driver=" + driver + 
				", maximumOnlineTicketnumber=" + maximumOnlineTicketnumber	+ 
				//", bookingOffice=" + bookingOffice + 
				"}";
	}

	
    
    
}
