package com.net.springboot.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.net.springboot.dto.BookingOfficeTripInfo;
import com.net.springboot.model.BookingOffice;

@Repository
public interface BookingRepository extends JpaRepository<BookingOffice, Long> {
	<T> List<T> findBy(Class<T> classType);

	@Query("SELECT b FROM BookingOffice b WHERE b.officeName LIKE %?1%")
	List<BookingOffice> findByOfficeName(String officeName);
	
	@Query("SELECT b FROM BookingOffice b WHERE b.officeName LIKE %?1%")
	List<BookingOfficeTripInfo> findByOfficeNameInfo(String officeName);
	
	Page<BookingOffice> findAll(Pageable pageable);
}
