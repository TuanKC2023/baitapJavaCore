package com.net.springboot.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.net.springboot.dto.CarParkingInfo;
import com.net.springboot.model.Car;

@Repository
public interface CarRepository extends JpaRepository<Car, String> {
	<T> List<T> findBy(Class<T> classType);

	Optional<Car> findByLicensePlace(String licensePlace);

	//search carType
	@Query("SELECT b FROM Car b WHERE b.carType LIKE %?1%")
	List<CarParkingInfo> findByCarTypeInfo(String carType);
	
	Page<Car> findAll(Pageable pageable);
}
