package com.net.springboot.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.net.springboot.dto.EmployeeInfo;
import com.net.springboot.model.Employee;

@Repository
public interface EmployeeRepository extends JpaRepository<Employee, Long> {
	<T> List<T> findBy(Class<T> classType);
	
	@Query("SELECT b FROM Employee b WHERE b.fullName LIKE %?1% ORDER BY b.fullName ASC")
	List<EmployeeInfo> findByEmployeeFullNameInfo(String fullName);
	
	@Query("SELECT e FROM Employee e")
	List<Employee> findAll(Sort sort);
	
	Page<Employee> findAll(Pageable pageable);
}
