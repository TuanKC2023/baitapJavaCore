package com.net.springboot.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.net.springboot.dto.BookingOfficeTripInfo;
import com.net.springboot.model.BookingOffice;
import com.net.springboot.repository.BookingRepository;

@Service
public class BookingServiceImpl implements BookingSevice {
	
	@Autowired
	private BookingRepository repo;
	
	//Get All
	@Override
	public List<BookingOffice> getAllListBooking() {
		return repo.findAll();
	}

	//Get All (use Projection)
	@Override
	public List<BookingOfficeTripInfo> getAllListBookingOfficeTripInfo() {
		return repo.findBy(BookingOfficeTripInfo.class);
	}
	
	

	//Get All (use Projection)
	@Override
	public List<BookingOffice> getAllListBookingOfficeTripInfo_Sort() {
		Sort sort = Sort.by(Sort.Direction.ASC, "officeName");
		List<BookingOffice> bookingOffice = repo.findAll(sort);
		return bookingOffice;
	}
	
	//Get By Id
	@Override
	public BookingOffice getBookingById(long id) {
		Optional<BookingOffice> optionalBooking = repo.findById(id);
		BookingOffice bookingOffice =null;
		if (optionalBooking.isPresent()) {
			bookingOffice = optionalBooking.get();
		}else {
			throw new RuntimeException("BookingOffice not found for id : " + id);
		}
		return bookingOffice;
	}

	//search By OfficeName
		@Override
		public List<BookingOffice> searchByOfficeName(String officeName) {
			return repo.findByOfficeName(officeName);
		}
		
	//Add BookingOffice
	@Override
	public BookingOffice addBooking(BookingOffice bookingOffice) {
		long officePriceChk = bookingOffice.getOfficePrice();
		if (officePriceChk == 0) {
			throw new RuntimeException("BookingOffice, Please enter officePrice <> : " + officePriceChk);
		}
		return this.repo.save(bookingOffice);
	}

    // search
	@Override
	public List<BookingOfficeTripInfo> searchByOfficeNameInfo(String officeName) {
		return repo.findByOfficeNameInfo(officeName);
	}

	@Override
	public Page<BookingOffice> getAllListBookingOffice_Pageable(int pageNumber, int pageSize, String sortBy) {

		   Pageable pageable = PageRequest.of(pageNumber, pageSize, Sort.by(sortBy));
		   return repo.findAll(pageable);
		}
}
