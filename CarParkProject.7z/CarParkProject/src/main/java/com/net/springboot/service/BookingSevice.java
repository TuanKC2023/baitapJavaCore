package com.net.springboot.service;

import java.util.List;

import org.springframework.data.domain.Page;

import com.net.springboot.dto.BookingOfficeTripInfo;
import com.net.springboot.model.BookingOffice;

public interface BookingSevice {
	//Get All
	List<BookingOffice> getAllListBooking();
	//Get All (use Projection)
	List<BookingOfficeTripInfo> getAllListBookingOfficeTripInfo();
	//Get By Id
	BookingOffice getBookingById(long id);
	//add BookingOffice
	BookingOffice addBooking(BookingOffice bookingOffice);
	//Search officeName
	List<BookingOffice> searchByOfficeName(String officeName);
	List<BookingOfficeTripInfo> searchByOfficeNameInfo(String officeName);
	List<BookingOffice> getAllListBookingOfficeTripInfo_Sort();
	Page<BookingOffice> getAllListBookingOffice_Pageable(int pageNumber, int pageSize, String sortBy);
}
