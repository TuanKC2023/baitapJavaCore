package com.net.springboot.service;

import java.util.List;

import org.springframework.data.domain.Page;

import com.net.springboot.dto.CarParkingInfo;
import com.net.springboot.model.Car;

public interface CarService {
	// Get All
	List<Car> getAllListCar();
	
	//Get All (use Projection)
	List<CarParkingInfo> getAllListCarParkingInfo();

	// Get By licensePlace
	Car getCarById(String licensePlace);

	// Add Car
	Car addCar(Car car);

	// Delete By licensePlace
	void deleteByLicensePlaceCar(String licensePlace);

	// Edit Car By licensePlace
	Car editCarByLicensePlace(Car car, String licensePlace);
	
	//Search 
	List<CarParkingInfo> searchByCarTypeInfo(String carType);
	
	Page<Car> getAllListCar_Pageable(int pageNumber, int pageSize, String sortBy);
}
