package com.net.springboot.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.net.springboot.dto.CarParkingInfo;
import com.net.springboot.model.Car;
import com.net.springboot.repository.CarRepository;

@Service
public class CarServiceImpl implements CarService {

	@Autowired
	private CarRepository repo;
	
	//Get All
	@Override
	public List<Car> getAllListCar() {
		return repo.findAll();
	}
	
	//Get All
	@Override
	public List<CarParkingInfo> getAllListCarParkingInfo() {
		return repo.findBy(CarParkingInfo.class);
	}

	//Get By Id
	@Override
	public Car getCarById(String licensePlace) {
		Optional<Car> optionalCar =repo.findById(licensePlace);
		Car car =null;
		if (optionalCar.isPresent()) {
			car = optionalCar.get();
		}else {
			//System.out.println("Car not found for licensePlace : "+licensePlace);
			throw new RuntimeException("Car not found for licensePlace : "+licensePlace);
		}
		return car;
	}

	//Add Car
	@Override
	public Car addCar(Car car) {
		boolean existCar = repo.existsById(car.getLicensePlace());
		if(existCar) {
			throw new RuntimeException("Car LicensePlace already taken  : " + car.getLicensePlace());
		}else {
			return this.repo.save(car);
		}
	}

	//Delete
	@Override
	public void deleteByLicensePlaceCar(String licensePlace) {
		boolean existCar = repo.existsById(licensePlace);
		if (existCar) {
			this.repo.deleteById(licensePlace);
		}else {
			throw new RuntimeException(" Cannot find Car to delete for licensePlace : " + licensePlace);
		}
	}

	//Edit
	@Override
	public Car editCarByLicensePlace(Car car, String licensePlace) {
		Optional<Car> optionalCar = repo.findById(licensePlace);
		Car newCar = null;
		if(optionalCar.isPresent()) {
			newCar = optionalCar.get();
			newCar.setCarColor(car.getCarColor());
			newCar.setCarType(car.getCarType());
			newCar.setCompany(car.getCompany());
			newCar.setParkingLot(car.getParkingLot());
		}else {
			throw new RuntimeException("Cannot find Car to edit for licensePlace : " + licensePlace);
		}
		return this.repo.save(newCar);
	}

	@Override
	public List<CarParkingInfo> searchByCarTypeInfo(String carType) {
		return repo.findByCarTypeInfo(carType);
	}

	@Override
	public Page<Car> getAllListCar_Pageable(int pageNumber, int pageSize, String sortBy) {
		Pageable pageable = PageRequest.of(pageNumber, pageSize, Sort.by(sortBy));
		   return repo.findAll(pageable);
	}

}
