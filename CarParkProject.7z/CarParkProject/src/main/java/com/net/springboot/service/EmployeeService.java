package com.net.springboot.service;

import java.util.List;

import org.springframework.data.domain.Page;

import com.net.springboot.dto.EmployeeInfo;
import com.net.springboot.model.Employee;

public interface EmployeeService {

	// Get all Employee
	List<Employee> getAllEmployee();
	//Get All (use Projection)
	List<EmployeeInfo> getAllListEmployeeInfo();
	// Get By Id
	Employee getEmployeeById(long id);

	// add Employee
	Employee addEmployee(Employee employee);

	// delete By Id
	void deleteByIdEmployee(long id);

	//Edit
	Employee editEmployeeById(Employee employee, long id);
	//Sear Fullname
	List<EmployeeInfo> searchByEmployyeeFullNameInfo(String fullName);
	Page<Employee> getAllListEmployee_Pageable(int pageNumber, int pageSize, String sortBy);
}
