package com.net.springboot.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.net.springboot.dto.EmployeeInfo;
import com.net.springboot.model.Employee;
import com.net.springboot.repository.EmployeeRepository;

@Service
public class EmployeeServiceImpl implements EmployeeService {

	@Autowired
	private EmployeeRepository repo;
	
	//Get all Employee
	@Override
	public List<Employee> getAllEmployee() {
		return repo.findAll();
	}
	
	//get by Id
	@Override
	public Employee getEmployeeById(long id) {
		Optional<Employee> optional = repo.findById(id);
		
		Employee employee = null;
		
		if(optional.isPresent()) {
			employee = optional.get();
		}else {
			throw new RuntimeException(" Employee not found for id : " + id);
		}
		return employee;
	} 
	
	//add Employee
	@Override
	public Employee addEmployee(Employee employee) {
		return this.repo.save(employee);		
	}
	
	//delete
	@Override
	public void deleteByIdEmployee(long id) {
		boolean existEmployee = repo.existsById(id);
		if (existEmployee) {
			this.repo.deleteById(id);
		}else {
			throw new RuntimeException(" Employee not found for id : " + id);
		}
		
		
	}
	
	//Edit
	@Override
	public Employee editEmployeeById(Employee employee, long id) {
		Optional<Employee> optionalEmployee = repo.findById(id);
		Employee newEmployee = null;
		if(optionalEmployee.isPresent()) {
			newEmployee = optionalEmployee.get();
			newEmployee.setAcount(employee.getAcount());
			newEmployee.setDepartment(employee.getDepartment());
			newEmployee.setAddress(employee.getAddress());
			newEmployee.setDateOfBirth(employee.getDateOfBirth());
			newEmployee.setEmail(employee.getEmail());			
			newEmployee.setFullName(employee.getFullName());
			newEmployee.setPhoneNumber(employee.getPhoneNumber());
			newEmployee.setPassword(employee.getPassword());			
			newEmployee.setSex(employee.getSex());
		}else {
			throw new RuntimeException("Cannot find Employee to edit for id : " + id);
		}
		return this.repo.save(newEmployee);
	}

	//Search FullName
	@Override
	public List<EmployeeInfo> searchByEmployyeeFullNameInfo(String fullName) {
		return repo.findByEmployeeFullNameInfo(fullName);
	}
	
	//Get All (use Projection)
	@Override
	public List<EmployeeInfo> getAllListEmployeeInfo() {
		return repo.findBy(EmployeeInfo.class);
	}

	@Override
	public Page<Employee> getAllListEmployee_Pageable(int pageNumber, int pageSize, String sortBy) {

		   Pageable pageable = PageRequest.of(pageNumber, pageSize, Sort.by(sortBy));
		   return repo.findAll(pageable);
		}	
}
