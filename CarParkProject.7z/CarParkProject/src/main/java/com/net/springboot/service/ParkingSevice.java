package com.net.springboot.service;

import java.util.List;

import org.springframework.data.domain.Page;

import com.net.springboot.model.ParkingLot;

public interface ParkingSevice {
	// Get All
	List<ParkingLot> getAllListParking();

	// Get By Id
	ParkingLot getParkingById(long id);

	// Add Trip
	ParkingLot addParkingLot(ParkingLot parking);

	// Delete By Id
	void deleteByIdParkingLot(long id);

	// Edit ParkingLot By Id
	ParkingLot editParkingById(ParkingLot parking, long id);
	
	//search
	List<ParkingLot> searchByParkNameInfo(String parkName);

	Page<ParkingLot> getAllListParkingLot_Pageable(int pageNumber, int pageSize, String sortBy);
}
