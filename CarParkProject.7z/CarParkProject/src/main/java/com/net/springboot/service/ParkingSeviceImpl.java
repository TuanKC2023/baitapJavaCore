package com.net.springboot.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.net.springboot.model.ParkingLot;
import com.net.springboot.repository.ParkingRepository;
@Service
public class ParkingSeviceImpl implements ParkingSevice{

	@Autowired
	private ParkingRepository repo;
	
	//Get All
	@Override
	public List<ParkingLot> getAllListParking() {
		return repo.findAll();
	}

	//Get By Id
	@Override
	public ParkingLot getParkingById(long id) {
		Optional<ParkingLot> optionalParking = repo.findById(id);
		ParkingLot parkingLot = null;
		if(optionalParking.isPresent()) {
			parkingLot= optionalParking.get();
			
		}else {
			throw new RuntimeException("ParkingLot not found for id : " + id);
		}
		return parkingLot;
	}
	
	//Add ParkingLot
	@Override
	public ParkingLot addParkingLot(ParkingLot parkingLot) {
		List<ParkingLot> existParking = repo.findByParkName(parkingLot.getParkName());
		if(existParking.size() > 0) {
			throw new RuntimeException("Parking ParkName already taken  : " + parkingLot.getParkName());
		}
		long parkPriceChk = parkingLot.getParkPrice();
		long parkAreaChk = parkingLot.getParkArea();
		if (parkPriceChk == 0) {
			throw new RuntimeException("ParkingLot, Please enter parkPrice <> : " + parkPriceChk);
		}else if (parkAreaChk == 0) {
			throw new RuntimeException("ParkingLot, Please enter parkArea <> : " + parkAreaChk);
		}else{
			return this.repo.save(parkingLot);
		}		
	}

	//Delete
	@Override
	public void deleteByIdParkingLot(long id) {
		boolean existParking = repo.existsById(id);
		System.out.println("existParking: " +existParking);
		if (existParking) {
			this.repo.deleteById(id);
		}else {
			throw new RuntimeException(" Cannot find ParkingLot to delete for id : " + id);
		}
	}
	
	public void softDelete(long id) {
		ParkingLot parking = repo.findById(id).get();
	       //parking.setDeleted(true);

	       repo.save(parking);
	   }

	//Edit
	@Override
	public ParkingLot editParkingById(ParkingLot parking, long id) {
		Optional<ParkingLot> optionalParking = repo.findById(id);
		ParkingLot parkingLot = null;
		if(optionalParking.isPresent()) {			
			parkingLot= optionalParking.get();
			parkingLot.setParkArea(parking.getParkArea());
			parkingLot.setParkName(parking.getParkName());
			parkingLot.setParkPlace(parking.getParkPlace());
			parkingLot.setParkPrice(parking.getParkPrice());
			parkingLot.setParkStatus(parking.getParkStatus());
			List<ParkingLot> existParking = repo.findByParkName(parkingLot.getParkName());
			if(existParking.size() >0) {
				throw new RuntimeException("Parking ParkName already taken  : " + parkingLot.getParkName());
			}
			long parkPriceChk = parkingLot.getParkPrice();
			long parkAreaChk = parkingLot.getParkArea();
			if (parkPriceChk == 0) {
				throw new RuntimeException("ParkingLot, Please enter parkPrice <> : " + parkPriceChk);
			}else if (parkAreaChk == 0) {
				throw new RuntimeException("ParkingLot, Please enter parkArea <> : " + parkAreaChk);
			}
		}else {
			throw new RuntimeException("Cannot find ParkingLot to edit for id : " + id);
		}
		return this.repo.save(parkingLot);
	}

	//Search parkName
	@Override
	public List<ParkingLot> searchByParkNameInfo(String parkName) {
		return repo.findByParkNameInfo(parkName);
	}
	
	@Override
	public Page<ParkingLot> getAllListParkingLot_Pageable(int pageNumber, int pageSize, String sortBy) {

		   Pageable pageable = PageRequest.of(pageNumber, pageSize, Sort.by(sortBy));
		   return repo.findAll(pageable);
		}
}
