package com.net.springboot.service;

import java.util.List;

import org.springframework.data.domain.Page;

import com.net.springboot.dto.TicketTripCarInfo;
import com.net.springboot.model.Ticket;

public interface TicketService {
	// Get All
	List<Ticket> getAllListTicket();

	// Get All (use Projection)
	List<TicketTripCarInfo> getAllListTicketTripCarInfo();

	// Get By Id
	Ticket getTicketById(long id);

	// add Ticket
	Ticket addTicket(Ticket ticket);

	// delete By Id
	void deleteTicketById(long id);

	// search
	List<TicketTripCarInfo> searchByCustomerNameInfo(String customerName);

	Page<Ticket> getAllListTicket_Pageable(int pageNumber, int pageSize, String sortBy);
}
