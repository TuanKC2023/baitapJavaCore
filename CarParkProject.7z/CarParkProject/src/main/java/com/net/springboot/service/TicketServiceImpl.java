package com.net.springboot.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.net.springboot.dto.TicketTripCarInfo;
import com.net.springboot.model.Ticket;
import com.net.springboot.repository.TicketRepository;

@Service
public class TicketServiceImpl implements TicketService{

	@Autowired
	private TicketRepository repo; 
	@Override
	public List<Ticket> getAllListTicket() {
		return repo.findAll();
	}
	
	@Override
	public List<TicketTripCarInfo> getAllListTicketTripCarInfo() {
		return repo.findBy(TicketTripCarInfo.class);
	}

	@Override
	public Ticket getTicketById(long id) {
		Optional<Ticket> optionalTicket = repo.findById(id);
		Ticket ticket =null;
		if(optionalTicket.isPresent()){
			ticket = optionalTicket.get();
		}else {
			throw new RuntimeException("Ticket not found for id : " + id);
		}
		return ticket;
	}

	@Override
	public Ticket addTicket(Ticket ticket) {
		return this.repo.save(ticket);
	}

	@Override
	public void deleteTicketById(long id) {
		boolean existTicket = repo.existsById(id);
		if (existTicket) {
			this.repo.deleteById(id);
		}else {
			throw new RuntimeException(" Cannot find Ticket to delete for id : " + id);
		}		
	}

	@Override
	public List<TicketTripCarInfo> searchByCustomerNameInfo(String customerName) {
		return repo.findByCustomerNameInfo(customerName);
	}
	
	@Override
	public Page<Ticket> getAllListTicket_Pageable(int pageNumber, int pageSize, String sortBy) {

		   Pageable pageable = PageRequest.of(pageNumber, pageSize, Sort.by(sortBy));
		   return repo.findAll(pageable);
		}
}
