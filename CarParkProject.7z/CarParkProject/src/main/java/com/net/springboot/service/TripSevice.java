package com.net.springboot.service;

import java.util.List;

import org.springframework.data.domain.Page;

import com.net.springboot.model.Trip;

public interface TripSevice {
	// Get All
	List<Trip> getAllListTrip();

	// Get By Id
	Trip getTripById(long id);

	// add Trip
	Trip addTrip(Trip trip);

	// Delete By Id
	void deleteByIdTrip(long id);

	// Edit Trip By Id
	Trip editTripById(Trip trip, long id);
	//Search
	List<Trip> searchByDriver(String driver);

	Page<Trip> getAllListTrip_Pageable(int pageNumber, int pageSize, String sortBy);
}
