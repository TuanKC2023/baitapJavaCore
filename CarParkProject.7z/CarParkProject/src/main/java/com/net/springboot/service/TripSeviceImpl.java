package com.net.springboot.service;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.net.springboot.model.Trip;
import com.net.springboot.repository.TripRepository;

@Service
public class TripSeviceImpl implements TripSevice {

	@Autowired
	private TripRepository repo;

	// Get All
	@Override
	public List<Trip> getAllListTrip() {
		return repo.findAll();
	}

	// Get By Id
	@Override
	public Trip getTripById(long id) {
		Optional<Trip> optionalTrip = repo.findById(id);
		Trip trip = null;
		if (optionalTrip.isPresent()) {
			trip = optionalTrip.get();
		} else {
			throw new RuntimeException("Trip not found for id : " + id);
		}
		return trip;
	}

	// Add Trip
	@Override
	public Trip addTrip(Trip trip) {
		long maximumOnlineTicketnumberChk = trip.getMaximumOnlineTicketnumber();
		if (maximumOnlineTicketnumberChk == 0) {
			throw new RuntimeException("Trip, Please enter maximumOnlineTicketnumber <> : " + maximumOnlineTicketnumberChk);
		}
		return this.repo.save(trip);
		
	}
	
	
	String regexp = "^([01]?[0-9]|2[0-3]):[0-5][0-9]:[0-5][0-9]$)"; //, message = "Invalid time format, should be hh:mm:ss"));
	public boolean isValidDate(String dateStr, String format) {
		   DateFormat sdf = new SimpleDateFormat(format);
		   sdf.setLenient(false);
		   try {
		       sdf.parse(dateStr);
		   } catch (ParseException e) {
		       return false;
		   }
		   return true;
		}



	@Override
	public void deleteByIdTrip(long id) {
		boolean existTrip = repo.existsById(id);
		System.out.println("existTrip: " +existTrip);
		if (existTrip) {
			this.repo.deleteById(id);
		}else {
			throw new RuntimeException(" Cannot find Trip to delete for id : " + id);
		}
	}

	@Override
	public Trip editTripById(Trip trip, long id) {
		Optional<Trip> optionalTrip = repo.findById(id);
		Trip newTrip = null;
		if(optionalTrip.isPresent()) {
			newTrip = optionalTrip.get();
			newTrip.setBookedTicketnumber(trip.getBookedTicketnumber());
			newTrip.setCarType(trip.getCarType());
			newTrip.setDepartureDate(trip.getDepartureDate());
			newTrip.setDepartureTime(trip.getDepartureTime());
			newTrip.setDepartureDate(trip.getDepartureDate());
			newTrip.setDestination(trip.getDestination());
			newTrip.setDriver(trip.getDriver());
			newTrip.setMaximumOnlineTicketnumber(trip.getMaximumOnlineTicketnumber());
			long maximumOnlineTicketnumberChk = newTrip.getMaximumOnlineTicketnumber();
			if (maximumOnlineTicketnumberChk == 0) {
				throw new RuntimeException("Trip, Please enter maximumOnlineTicketnumber <> : " + maximumOnlineTicketnumberChk);
			}
		}else {
			throw new RuntimeException("Cannot find Trip to edit for id : " + id);
		}
		return this.repo.save(newTrip);
	}

	@Override
	public List<Trip> searchByDriver(String driver) {
		return repo.findByDriver(driver);
	}
	
	@Override
	public Page<Trip> getAllListTrip_Pageable(int pageNumber, int pageSize, String sortBy) {

		   Pageable pageable = PageRequest.of(pageNumber, pageSize, Sort.by(sortBy));
		   return repo.findAll(pageable);
		}
}
