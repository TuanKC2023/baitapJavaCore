package b3;

public class Student {
	protected String idNumber;
	protected String name;
	protected String address;
	protected int priorityLevel;
	
	public Student(String idNumber, String name, String address, int priorityLevel) {
		this.idNumber = idNumber;
		this.name = name;
		this.address = address;
		this.priorityLevel = priorityLevel;				
	}
	
	public String getIdNumber() {
		return idNumber;
	}
	public void setIdNumber(String idNumber) {
		this.idNumber = idNumber;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	public String getAddress() {
        return address;
    }
	public void setAddress(String address) {
        this.address = address;
    }
	
	public int getPriorityLevel() {
		return priorityLevel;
	}
	public void setPriorityLeveln(int priorityLevel) {
		this.priorityLevel = priorityLevel;
	}
}
