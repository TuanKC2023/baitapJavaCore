package b3;

public class StudentA extends Student{
	public static final String Mon_Toan = "Toan";
	public static final String Mon_Ly = "Ly";
	public static final String Mon_Hoa = "Hoa";
	
	public StudentA(String idNumber, String name, String address, int priorityLevel) {
		super(idNumber, name, address, priorityLevel);
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public String toString() {
		return "Sinh Vien khoi A {"+
				"idNumber = '" + idNumber + '\'' +
				", name = '" + name + '\'' +
				", address = '" + address + '\'' +
				", priorityLevel = " + priorityLevel +
				", Grade A = " + Mon_Toan + " - " + Mon_Ly + " - " + Mon_Hoa +
				"}";
		
	}

}
