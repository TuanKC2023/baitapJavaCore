package b3;

public class StudentB extends Student{
	public static final String Mon_Toan = "Toan";
	public static final String Mon_Sinh = "Sinh";
	public static final String Mon_Hoa = "Hoa";
	
	public StudentB(String idNumber, String name, String address, int priorityLevel) {
		super(idNumber, name, address, priorityLevel);
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public String toString() {
		return "Sinh Vien khoi B {"+
				"idNumber = '" + idNumber + '\'' +
				", name = '" + name + '\'' +
				", address = '" + address + '\'' +
				", priorityLevel = " + priorityLevel +
				", Grade B = " + Mon_Toan + " - " + Mon_Hoa + " - " + Mon_Sinh +
				"}";
		
	}

}
