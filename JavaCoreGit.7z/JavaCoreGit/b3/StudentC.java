package b3;

public class StudentC extends Student{
	public static final String Mon_Van = "Van";
	public static final String Mon_Su = "Su";
	public static final String Mon_Dia = "Dia";
	
	public StudentC(String idNumber, String name, String address, int priorityLevel) {
		super(idNumber, name, address, priorityLevel);
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public String toString() {
		return "Sinh Vien khoi C {"+
				"idNumber = '" + idNumber + '\'' +
				", name = '" + name + '\'' +
				", address = '" + address + '\'' +
				", priorityLevel = " + priorityLevel +
				", Grade C = " + Mon_Van + " - " + Mon_Su + " - " + Mon_Dia +
				"}";
		
	}

}
