package b3;

import java.util.ArrayList;
import java.util.List;

public class StudentManager {
	List<Student> students;
	public StudentManager() {
		students = new ArrayList<>();
	}
	public void add(Student student) {
		this.students.add(student);
	}
	public void ShowInfor() {
		this.students.forEach(student -> System.out.println(student.toString()));
	}
	public Student searchByIdNumber(String id) {
		return this.students.stream().filter(student -> student.getIdNumber().equals(id)).findFirst().orElse(null);
		
	}
}
