package b3;

import java.util.Scanner;

public class mainStudent {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner(System.in);
		StudentManager studentManager = new StudentManager();
		while (true) {
			System.out.println("Application Sudent Manager");
			System.out.println("Enter 1: To insert Student");
			System.out.println("Enter 2: To show Students'information");
			System.out.println("Enter 3: To search Student by id");
			System.out.println("Enter 4: To Exit");
			System.out.println("Please choose a number above");
			String inputNumber = scanner.nextLine();
			switch(inputNumber) {
				case "1": {
					System.out.println("Enter a: to insert Student Grade A");
					System.out.println("Enter b: to insert Student Grade B");
	                System.out.println("Enter c: to insert Student Grade C");
	                System.out.println("Please choose a character above");
	                String typeCharacter = scanner.nextLine();
	        		switch(typeCharacter) {
	    			case "a": {
	    				System.out.println("Add Student Grade A");    				
	    				System.out.print("Enter ID:");
	    				String id = scanner.nextLine();    				
	    				System.out.print("Enter name:");
	    				String name = scanner.nextLine();
	    				System.out.print("Enter address:");
	    				String address = scanner.nextLine();    				
	    				System.out.print("Enter priorityLevel:");
	    				int priorityLevel = scanner.nextInt();
	    				Student studentA = new StudentA(id, name, address, priorityLevel);
	    				studentManager.add(studentA);
	    				System.out.println(studentA.toString());
	    				scanner.nextLine();
	                    break;
	    			}
	    			case "b": {
	    				System.out.println("Add Student Grade B");    				
	    				System.out.print("Enter ID:");
	    				String id = scanner.nextLine();    				
	    				System.out.print("Enter name:");
	    				String name = scanner.nextLine();
	    				System.out.print("Enter address:");
	    				String address = scanner.nextLine();    				
	    				System.out.print("Enter priorityLevel:");
	    				int priorityLevel = scanner.nextInt();
	    				Student studentB = new StudentB(id, name, address, priorityLevel);
	    				studentManager.add(studentB);
	    				System.out.println(studentB.toString());
	    				scanner.nextLine();
	                    break;
	    			}
	    			case "c": {
	    				System.out.println("Add Student Grade C");    				
	    				System.out.print("Enter ID:");
	    				String id = scanner.nextLine();    				
	    				System.out.print("Enter name:");
	    				String name = scanner.nextLine();
	    				System.out.print("Enter address:");
	    				String address = scanner.nextLine();    				
	    				System.out.print("Enter priorityLevel:");
	    				int priorityLevel = scanner.nextInt();
	    				Student studentC = new StudentC(id, name, address, priorityLevel);
	    				studentManager.add(studentC);
	    				System.out.println(studentC.toString());
	    				scanner.nextLine();
	                    break;
	    			}
	    			default:
	    				System.out.println("Invalid");
	    				break;
	        		}
	        		break;
				}
				case "2": {
					studentManager.ShowInfor();
					break;
					
				}
				case "3": {
					System.out.print("Enter ID Number:");
    				String id = scanner.nextLine();
    				Student student = studentManager.searchByIdNumber(id);
    				if (student !=null) {
    					System.out.println(student.toString());
    				}
    				else {
    					System.out.println("Not found please!");
    				}
    				break;
					
				}
				case "4": {
					return;
				}
				default:
					System.out.println("Invalid");
					continue;
			}
			
			
			
			//scanner.close();
		}
	}
}
