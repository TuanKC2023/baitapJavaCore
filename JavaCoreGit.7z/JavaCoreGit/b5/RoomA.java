package b5;

public class RoomA extends Room {

	public RoomA() {
		super("A", 500);
		// TODO Auto-generated constructor stub
	}

    @Override
    public String toString() {
        return "RoomA{" +
                "category='" + category + '\'' +
                ", price=" + price +
                '}';
    }
}
