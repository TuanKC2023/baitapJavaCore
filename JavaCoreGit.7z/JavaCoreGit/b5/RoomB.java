package b5;

public class RoomB extends Room {

	public RoomB() {
		super("B", 300);
		// TODO Auto-generated constructor stub
	}
    
    @Override
    public String toString() {
        return "RoomB{" +
                "category='" + category + '\'' +
                ", price=" + price +
                '}';
    }
}
