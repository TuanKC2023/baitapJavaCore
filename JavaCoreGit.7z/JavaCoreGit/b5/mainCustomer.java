package b5;

import java.util.Scanner;

public class mainCustomer {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//while (true) {
		Scanner scanner = new Scanner(System.in);
        Hotel hotel = new Hotel();

        while (true) {
			System.out.println("Application Manager Customer");
			System.out.println("Enter: 1 - Insert customer");
			System.out.println("Enter: 2 - Remove customer");
			System.out.println("Enter: 3 - Calculator price room for customer");
			System.out.println("Enter: 4 - To show information Customer");
			System.out.println("Enter 5: To exit:");
			System.out.println("Please choose a number above");
			String line = scanner.nextLine();
            switch(line) {
            case "1": {
            	System.out.println("Please enter Customer's information :");
                System.out.print("Enter name: ");
                String name = scanner.nextLine();
                System.out.print("Enter age: ");
                int age = scanner.nextInt();
                System.out.print("Enter passport: ");
                scanner.nextLine();
                String passport = scanner.nextLine();
                System.out.println("Choise a to rent room type A");
                System.out.println("Choise b to rent room type B");
                System.out.println("Choise c to rent room type C");
                System.out.println("Please choose a character above");
                String choise = scanner.nextLine();
                Room room;
                if (choise.equals("a")) {
                    room = new RoomA();
                } else if (choise.equals("b")) {
                    room = new RoomB();
                } else if (choise.equals("c")) {
                    room = new RoomC();
                } else {
                    continue;
                }
                System.out.print("Enter number day for rent: ");
                int numberRent = scanner.nextInt();
                Person person = new Person(name, age, passport, room, numberRent);
                hotel.add(person);
                scanner.nextLine();
                break;
            }
            case "2": {
                System.out.print("Enter passport: ");
                String passport = scanner.nextLine();
                hotel.delete(passport);
                break;
            }
            case "3": {
                System.out.print("Enter passport: ");
                String passport = scanner.nextLine();
                System.out.println("Price: " + hotel.calculator(passport));
                break;
            }
            case "4": {
                hotel.show();
                break;
            }
            case "5": {
                return;
            }
            default:
                System.out.println("Invalid");
                continue;
            }
		}
	}
        
}
