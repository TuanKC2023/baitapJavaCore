package com.example.studentmanagement;

import java.util.LinkedList;
import java.util.Scanner;
public class LinkedListExample {
    public static void main(String[] args) {
        LinkedList<String> linkedList = new LinkedList<>();
        // Thêm các phần tử vào danh sách
        linkedList.add("1");
        linkedList.add("2");
        linkedList.add("3");
        linkedList.add("4");
        linkedList.add("5");
        linkedList.add("6");
        // Duyệt qua danh sách để xóa nút thứ 5
        Scanner scanner = new Scanner(System.in);
        int positionToRemove = scanner.nextInt(); // Vị trí thứ 5 (chỉ số bắt đầu từ 0)
        if (positionToRemove >= 0 && positionToRemove < linkedList.size()) {
            linkedList.remove(positionToRemove);
        } else {
            System.out.println("Vị trí không hợp lệ.");
        }
        // In danh sách sau khi xóa
        for (String item : linkedList) {
            System.out.print(item + " ");
        }
    }
}
