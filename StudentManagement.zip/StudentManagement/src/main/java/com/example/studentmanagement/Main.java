package com.example.studentmanagement;

import com.example.studentmanagement.dao.GoodStudentDao;
import com.example.studentmanagement.dao.NormalStudentDao;
import com.example.studentmanagement.dao.StudentDao;
import com.example.studentmanagement.dao.impl.GoodStudentDaoImpl;

import com.example.studentmanagement.dao.impl.NormalStudentDaoImpl;
import com.example.studentmanagement.dao.impl.StudentDaoImpl;
import com.example.studentmanagement.entity.*;

import org.springframework.util.comparator.ComparableComparator;


import java.sql.SQLException;
import java.util.*;

public class Main {
    static int recruited;
    public static void main(String[] args) throws SQLException {

        Person person1 = new Person("ngọc",18);
        Person person2 = new Person("ngọc",18);
        System.out.println(person1.equals(person2));
        GoodStudentDao goodStudentDao = new GoodStudentDaoImpl();
        List<GoodStudent> goodStudentList = goodStudentDao.getAll();
        NormalStudentDao normalStudentDao = new NormalStudentDaoImpl();
        List<NormalStudent> normalStudentList = normalStudentDao.getAll();
        StudentDao studentDao = new StudentDaoImpl();
        List<StudentFullNamePhoneNumber>  studentFullNamePhoneNumberList = studentDao.getAll();
        Scanner scanner = new Scanner(System.in);
        do {
            System.out.println("Enter the number of students to recruit (min 11/ max 17) : ");
            recruited = scanner.nextInt();
        } while (recruited < 11 || recruited > 17);
//        if (goodStudentList.size() >= recruited) {
//            Collections.sort(goodStudentList, new ComparableComparator<GoodStudent>() {
//                public int compare(GoodStudent goodStudent1, GoodStudent goodStudent2) {
//                    int gpaCompare = Double.compare(goodStudent2.getGpa(), goodStudent1.getGpa());
//                    if (gpaCompare != 0) {
//                        return gpaCompare;
//                    } else {
//                        return goodStudent1.getFullName().compareTo(goodStudent2.getFullName());
//                    }
//                }
//            });
//            List<GoodStudent> recruitedStudent = goodStudentList.subList(0, recruited);
//            recruitedStudent.forEach(System.out::println);
//        } else {
//            Collections.sort(normalStudentList, new ComparableComparator<NormalStudent>(){
//                public int compare(NormalStudent normalStudent1, NormalStudent normalStudent2){
//                    int englishCompare = Double.compare(normalStudent1.getEnglishScore(), normalStudent2.getEnglishScore());
//                    if (englishCompare != 0){
//                        return englishCompare;
//                    } else {
//                        return normalStudent1.getFullName().compareTo(normalStudent2.getFullName());
//                    }
//                }
//            });
//            List<NormalStudent> recruitedStudent2 = normalStudentList.subList(0, recruited - goodStudentList.size());
//            goodStudentList.forEach(System.out::println);
//            recruitedStudent2.forEach(System.out::println);
//        }
        if (goodStudentList.size() >= recruited){
            goodStudentList.stream()
                    .sorted((goodStudent1, goodStudent2) -> {
                        int gpaCompare = Double.compare(goodStudent2.getGpa(), goodStudent1.getGpa());
                        return gpaCompare != 0 ? gpaCompare : goodStudent1.getFullName().compareTo(goodStudent2.getFullName());
                    })
                    .limit(recruited)
                    .forEach(System.out::println);
        } else {
            goodStudentList.forEach(System.out::println);
            normalStudentList.stream()
                    .sorted((normalStudent1, normalStudent2) -> {
                        int englishCompare = Double.compare(normalStudent2.getEnglishScore(), normalStudent1.getEnglishScore());
                        return englishCompare != 0 ? englishCompare : normalStudent1.getFullName().compareTo(normalStudent2.getFullName());
                    })
                    .limit(recruited - goodStudentList.size())
                    .forEach(System.out::println);
        }
        System.out.println("============================");
        System.out.println("Show all Student");
        studentFullNamePhoneNumberList.forEach(System.out::println);




    }

}
