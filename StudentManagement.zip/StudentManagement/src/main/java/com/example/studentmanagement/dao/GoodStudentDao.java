package com.example.studentmanagement.dao;

import com.example.studentmanagement.entity.GoodStudent;

import java.util.List;

public interface GoodStudentDao {
    List<GoodStudent> getAll();



}
