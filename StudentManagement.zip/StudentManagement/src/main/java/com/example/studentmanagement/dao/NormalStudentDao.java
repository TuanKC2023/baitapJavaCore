package com.example.studentmanagement.dao;

import com.example.studentmanagement.entity.NormalStudent;

import java.util.List;

public interface NormalStudentDao {
    List<NormalStudent> getAll();
}
