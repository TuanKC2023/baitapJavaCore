package com.example.studentmanagement.dao;

import com.example.studentmanagement.entity.Student;
import com.example.studentmanagement.entity.StudentFullNamePhoneNumber;

import java.sql.SQLException;
import java.util.List;

public interface StudentDao {
    List<StudentFullNamePhoneNumber> getAll() throws SQLException;
}
