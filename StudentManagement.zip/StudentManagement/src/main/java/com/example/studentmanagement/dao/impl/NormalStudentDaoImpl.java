package com.example.studentmanagement.dao.impl;

import com.example.studentmanagement.dao.GoodStudentDao;
import com.example.studentmanagement.dao.NormalStudentDao;
import com.example.studentmanagement.entity.GoodStudent;
import com.example.studentmanagement.entity.NormalStudent;
import com.example.studentmanagement.enums.Gender;
import com.example.studentmanagement.enums.GradeLevel;
import com.example.studentmanagement.exception.InvalidDOBException;
import com.example.studentmanagement.exception.InvalidFullNameException;
import com.example.studentmanagement.exception.InvalidPhoneNumberException;
import com.example.studentmanagement.util.DBConnectionUtil;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.util.LinkedList;
import java.util.List;

public class NormalStudentDaoImpl implements NormalStudentDao {
    @Override
    public List<NormalStudent> getAll() {

        try (Connection connection = DBConnectionUtil.getConnection()) {
            Statement statement = connection.createStatement();

            ResultSet resultSet = statement.executeQuery("SELECT * FROM NormalStudent");
            List<NormalStudent> normalStudentList = new LinkedList<>();
            while (resultSet.next()) {
                String fullName = resultSet.getString(1);
                java.util.Date doB = resultSet.getDate(2);
                Gender gender = Gender.valueOf(resultSet.getString(3));
                String phoneNumber = resultSet.getString(4);
                String universityName = resultSet.getString(5);
                GradeLevel gradeLevel = GradeLevel.valueOf(resultSet.getString(6));
                Double englishScore = resultSet.getDouble(7);
                Double entryTestScore = resultSet.getDouble(8);
                normalStudentList.add(new NormalStudent(fullName, doB, gender, phoneNumber, universityName, gradeLevel, englishScore , entryTestScore));
            }
            return normalStudentList;
        } catch (InvalidPhoneNumberException e) {
            throw new RuntimeException(e);
        } catch (InvalidFullNameException e) {
            throw new RuntimeException(e);
        } catch (InvalidDOBException e) {
            throw new RuntimeException(e);
        } catch (ParseException | SQLException e) {
            throw new RuntimeException(e);
        }
    }
}
