package com.example.studentmanagement.dao.impl;

import com.example.studentmanagement.dao.StudentDao;
import com.example.studentmanagement.entity.GoodStudent;
import com.example.studentmanagement.entity.Student;
import com.example.studentmanagement.entity.StudentFullNamePhoneNumber;
import com.example.studentmanagement.enums.Gender;
import com.example.studentmanagement.enums.GradeLevel;
import com.example.studentmanagement.util.DBConnectionUtil;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.LinkedList;
import java.util.List;

public class StudentDaoImpl implements StudentDao {
    @Override
    public List<StudentFullNamePhoneNumber> getAll() throws SQLException {
        try (Connection connection = DBConnectionUtil.getConnection()) {
            Statement statement = connection.createStatement();

            ResultSet resultSet = statement.executeQuery("SELECT fullName, phoneNumber FROM goodstudent\n" +
                    "UNION ALL\n" +
                    "SELECT fullName, phoneNumber FROM normalstudent\n" +
                    "ORDER BY fullName DESC, phoneNumber ASC;");
            List<StudentFullNamePhoneNumber> studentFullNamePhoneNumberList = new LinkedList<>();
            while (resultSet.next()) {
                String fullName = resultSet.getString(1);
                String phoneNumber = resultSet.getString(2);
                studentFullNamePhoneNumberList.add(new StudentFullNamePhoneNumber(fullName, phoneNumber));
            }
            return studentFullNamePhoneNumberList;

        }
    }
}
