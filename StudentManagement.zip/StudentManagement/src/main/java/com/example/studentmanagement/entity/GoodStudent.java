package com.example.studentmanagement.entity;

import com.example.studentmanagement.enums.Gender;
import com.example.studentmanagement.enums.GradeLevel;
import com.example.studentmanagement.exception.InvalidDOBException;
import com.example.studentmanagement.exception.InvalidFullNameException;
import com.example.studentmanagement.exception.InvalidPhoneNumberException;

import java.text.ParseException;
import java.util.Date;

public class GoodStudent extends Student implements Comparable<GoodStudent> {
    private Double gpa;
    private String bestRewardName;

    public GoodStudent(String fullName, Date doB, Gender gender, String phoneNumber, String universityName, GradeLevel gradeLevel, Double gpa, String bestRewardName) throws InvalidPhoneNumberException, InvalidFullNameException, InvalidDOBException, ParseException {
        super(fullName, doB, gender, phoneNumber, universityName, gradeLevel);
        this.gpa = gpa;
        this.bestRewardName = bestRewardName;
    }

    public GoodStudent() {
        super();
    }

    public GoodStudent(String fullName, String phoneNumber) {
    }

    public Double getGpa() {
        return gpa;
    }

    public void setGpa(Double gpa) {
        this.gpa = gpa;
    }

    public String getBestRewardName() {
        return bestRewardName;
    }

    public void setBestRewardName(String bestRewardName) {
        this.bestRewardName = bestRewardName;
    }

    @Override
    public String toString() {

        return  super.toString() +
                "GoodStudent{" +
                "gpa=" + gpa +
                ", bestRewardName='" + bestRewardName + '\'' +
                '}';
    }
    @Override
    public String ShowMyInfo(){
        return this.toString();
    }

    @Override
    public int compareTo(GoodStudent o) {
        return 0;
    }
}
