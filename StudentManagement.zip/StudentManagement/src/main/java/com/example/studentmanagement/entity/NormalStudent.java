package com.example.studentmanagement.entity;

import com.example.studentmanagement.enums.Gender;
import com.example.studentmanagement.enums.GradeLevel;
import com.example.studentmanagement.exception.InvalidDOBException;
import com.example.studentmanagement.exception.InvalidFullNameException;
import com.example.studentmanagement.exception.InvalidPhoneNumberException;

import java.text.ParseException;
import java.util.Date;

public class NormalStudent extends Student implements Comparable<NormalStudent> {
    private Double englishScore;
    private Double entryTestScore;

    public NormalStudent(String fullName, Date doB, Gender gender, String phoneNumber, String universityName, GradeLevel gradeLevel, Double englishScore, Double entryTestScore) throws InvalidPhoneNumberException, InvalidFullNameException, InvalidDOBException, ParseException {
        super(fullName, doB, gender, phoneNumber, universityName, gradeLevel);
        this.englishScore = englishScore;
        this.entryTestScore = entryTestScore;
    }

    public NormalStudent() {

    }

    public Double getEnglishScore() {
        return englishScore;
    }

    public void setEnglishScore(Double englishScore) {
        this.englishScore = englishScore;
    }

    public Double getEntryTestScore() {
        return entryTestScore;
    }

    public void setEntryTestScore(Double entryTestScore) {
        this.entryTestScore = entryTestScore;
    }

    @Override
    public String toString() {
        return super.toString() +
                "NormalStudent{" +
                "englishScore='" + englishScore + '\'' +
                ", entryTestScore=" + entryTestScore +
                '}';
    }

    @Override
    public int compareTo(NormalStudent o) {
        return 0;
    }
}
