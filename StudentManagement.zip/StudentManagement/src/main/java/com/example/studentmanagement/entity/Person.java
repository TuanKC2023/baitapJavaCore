package com.example.studentmanagement.entity;

public class Person  {
    public String name;
    public Integer age;

    public Person(String name, Integer age) {
        this.name = name;
        this.age = age;
    }
    @Override
    public boolean equals(Object object){
        if (this == object){
            return true;
        }
        if (object == null || getClass() != object.getClass()){
            return false;
        }
        Person other = (Person) object;
        return age == other.age && name.equals(other.name);
    }
}
