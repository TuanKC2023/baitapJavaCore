package com.example.studentmanagement.entity;

import com.example.studentmanagement.enums.Gender;
import com.example.studentmanagement.enums.GradeLevel;
import com.example.studentmanagement.exception.InvalidDOBException;
import com.example.studentmanagement.exception.InvalidFullNameException;
import com.example.studentmanagement.exception.InvalidPhoneNumberException;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Student {

    private String fullName;
    private Date doB;
    private Gender gender;
    private String phoneNumber;
    private String universityName;
    private GradeLevel gradeLevel;

    public Student(String fullName, Date doB, Gender gender, String phoneNumber, String universityName, GradeLevel gradeLevel) throws InvalidFullNameException, InvalidDOBException, InvalidPhoneNumberException, ParseException {
        setFullName(fullName);
        setDoB(doB);
        this.gender = gender;
        setPhoneNumber(phoneNumber);
        this.universityName = universityName;
        this.gradeLevel = gradeLevel;
    }
    public Student() {
    }

    public Student(String fullName, String phoneNumber) {
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) throws InvalidFullNameException {
        if (fullName.length() < 10 || fullName.length() > 50){
            throw new InvalidFullNameException("Invalid name length");
        }
        this.fullName = fullName;
    }
    public Date getDoB() {
        return doB;
    }
    // check format date từ DB
    public void setDoB(Date doB) throws ParseException, InvalidDOBException {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        try {
            this.doB = dateFormat.parse(String.valueOf(doB));
        } catch (ParseException e){
            throw new InvalidDOBException("Invalid date format for DOB");
        }
    }
    public Gender getGender() {
        return gender;
    }
    public void setGender(Gender gender) {
        this.gender = gender;
    }
    public String getPhoneNumber() {
        return phoneNumber;
    }
    // check sđt
    public void setPhoneNumber(String phoneNumber) throws InvalidPhoneNumberException {
        if (!phoneNumber.matches("^(090|098|091|031|035|038)\\d{7}$")){
            throw new InvalidPhoneNumberException("Invalid phone number format.");
        }
        this.phoneNumber = phoneNumber;
    }
    public String getUniversityName() {
        return universityName;
    }

    public void setUniversityName(String universityName) {
        this.universityName = universityName;
    }

    public GradeLevel getGradeLevel() {
        return gradeLevel;
    }

    public void setGradeLevel(GradeLevel gradeLevel) {
        this.gradeLevel = gradeLevel;
    }

    @Override
    public String toString() {
        // format ngày tháng năm (dd/MM/yyyy)
        SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy");
        String dobWithFormat = format.format(this.doB);
        return "Student{" +
                "fullName='" + fullName + '\'' +
                ", doB=" + dobWithFormat +
                ", gender=" + gender +
                ", phoneNumber='" + phoneNumber + '\'' +
                ", universityName='" + universityName + '\'' +
                ", gradeLevel=" + gradeLevel +
                '}';
    }

    public String ShowMyInfo(){
        return this.toString();
    }



}
