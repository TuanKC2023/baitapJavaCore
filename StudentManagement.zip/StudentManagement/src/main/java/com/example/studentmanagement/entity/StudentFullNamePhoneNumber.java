package com.example.studentmanagement.entity;

public class StudentFullNamePhoneNumber {
    private String fullName;
    private String phoneNumber;

    public StudentFullNamePhoneNumber(String fullName, String phoneNumber) {
    }

    @Override
    public String toString() {
        return "StudentFullNamePhoneNumber{" +
                "fullName='" + fullName + '\'' +
                ", phoneNumber='" + phoneNumber + '\'' +
                '}';
    }
}
