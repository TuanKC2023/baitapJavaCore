package com.example.studentmanagement.enums;

public enum Gender {
    MALE, FEMALE
}
