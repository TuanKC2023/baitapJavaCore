package com.example.studentmanagement.enums;

public enum GradeLevel {
    NORMAL, GOOD
}
