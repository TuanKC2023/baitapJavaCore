package com.example.studentmanagement.exception;

public class InvalidDOBException extends Exception{
    public InvalidDOBException(String message){
        super(message);
    }
}
