package com.example.studentmanagement.exception;

public class InvalidFullNameException extends Exception{
    public InvalidFullNameException(String message){
        super(message);
    }
}
