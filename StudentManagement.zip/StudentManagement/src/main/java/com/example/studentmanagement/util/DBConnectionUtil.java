package com.example.studentmanagement.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


public class DBConnectionUtil {
    private DBConnectionUtil(){

    }
    private static final String USER = "root";
    private static final String PASSWORD = "123456";
    private static final String URL_CONNECTION = "jdbc:mysql://localhost:3306/student_management";

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL_CONNECTION,
                                           USER,
                                           PASSWORD);
    }
}
